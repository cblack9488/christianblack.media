/* christianblack.media — all site content lives here.
   Plain data. Edit by hand, or open any page with ?edit to use Studio.
   Studio rewrites this whole file when you export. */

window.CB_CONTENT = {
  "site": {
    "name": "Christian Black",
    "mark": "CB",
    "domain": "christianblack.media",
    "email": "cblack9488@gmail.com",
    "markImage": "images/cb-crab.png",
    "social": [
      {
        "kind": "instagram",
        "handle": "@crustacean_black",
        "url": "https://www.instagram.com/crustacean_black/"
      },
      {
        "kind": "youtube",
        "handle": "@christianblack1",
        "url": "https://www.youtube.com/@christianblack1"
      }
    ],
    "contactNote": "for inquiries, media requests, licensing or collaboration",
    "cloudflareToken": "bcfa56db21444097b56f303096f57bfb",
    "seoTitle": "Christian Black — Journal",
    "seoDescription": "Essays, trip reports, techniques and beta",
    "support": {
      "label": "Supported by",
      "logo": "images/hmg-logo.png",
      "partners": [
        "Hyperlite Mountain Gear"
      ]
    }
  },
  "athlete": {
    "kicker": "Tick list",
    "seoTitle": "Climbing résumé — Christian Black",
    "seoDescription": "Selected ascents: first ascent of White Sapphire in the Kishtwar Valley, Golden Gate on El Capitan, Desert Solitaire, plus expeditions in Patagonia and Peru.",
    "title": "Around the world",
    "lede": "A short resume of climbing",
    "bands": [
      {
        "id": "up-high",
        "label": "Up high",
        "blurb": "Alpinism",
        "image": "images/up-high.jpg",
        "focus": "center 45%",
        "side": "left",
        "credit": "Photo · Christian Black",
        "items": [
          {
            "name": "Afanassieff",
            "grade": "5,000ft, Northwest Ridge",
            "detail": "Fitz Roy, Patagonia, Argentina",
            "note": "Summit",
            "url": "words/patagonia-pt-1-success.html"
          },
          {
            "name": "“Brilliant Blue”",
            "grade": "AI3 M7+, 850m",
            "detail": "White Sapphire (6040m), Kishtwar Valley, India",
            "note": "First ascent",
            "url": "words/brilliant-blue-first-all-american-expedition-to-india-s-kish.html"
          },
          {
            "name": "Para-alpinism in the Cordillera Blanca",
            "grade": "",
            "detail": "",
            "note": "",
            "url": "words/fight-or-flight.html"
          },
          {
            "name": "Failure or success? A trip to the Garhwal Himalaya",
            "grade": "",
            "detail": "",
            "note": "",
            "url": "words/garhwal-himalaya.html"
          }
        ]
      },
      {
        "id": "on-the-walls",
        "label": "On the walls",
        "blurb": "Big wall and multipitch free climbing",
        "image": "images/on-the-walls.jpg",
        "focus": "center 42%",
        "side": "right",
        "credit": "Photo · Scott Bennet",
        "items": [
          {
            "name": "“Golden Gate”",
            "grade": "5.13a, 36 pitches",
            "detail": "El Capitan, Yosemite CA",
            "note": "Ground up free ascent",
            "url": "words/the-golden-handcuffs.html"
          },
          {
            "name": "“Desert Solitaire”",
            "grade": "5.13b, 11 pitches",
            "detail": "Red Rock NV",
            "note": "In-a-day free ascent"
          },
          {
            "name": "“Westie Face”",
            "grade": "5.13a, 8 pitches",
            "detail": "Leaning Tower, Yosemite CA",
            "note": "Ground up free ascent"
          }
        ]
      },
      {
        "id": "down-low",
        "label": "Down low",
        "blurb": "Sport climbing and bouldering",
        "image": "images/down-low.jpg",
        "focus": "center 38%",
        "side": "left",
        "credit": "Photo · Dan Teitelbaum",
        "items": [
          {
            "name": "“Dante’s Inferno” (extension)",
            "grade": "5.13d",
            "detail": "El Salto, MX",
            "note": ""
          },
          {
            "name": "“America’s Most Wanted”",
            "grade": "5.13c",
            "detail": "Mt. Charleston, NV",
            "note": ""
          },
          {
            "name": "“The Force”",
            "grade": "V9",
            "detail": "Yosemite, California",
            "note": "One session"
          },
          {
            "name": "“Gato Negro” (sit)",
            "grade": "V10",
            "detail": "El Chaltén, Argentina",
            "note": "Two sessions"
          }
        ]
      },
      {
        "id": "far-away",
        "label": "Far away",
        "blurb": "Expeditions",
        "image": "images/far-away.jpg",
        "focus": "center 45%",
        "side": "right",
        "credit": "Photo · Hayden Wyatt",
        "items": [
          {
            "name": "Indian Himalaya",
            "grade": "",
            "detail": "Kishtwar Valley",
            "note": "",
            "url": "words/brilliant-blue-first-all-american-expedition-to-india-s-kish.html"
          },
          {
            "name": "Cordillera Blanca",
            "grade": "",
            "detail": "Peru — climb and fly",
            "note": "",
            "url": "words/fight-or-flight.html"
          },
          {
            "name": "Patagonia",
            "grade": "",
            "detail": "El Chaltén, Argentina",
            "note": "",
            "url": "words/patagonia-pt-1-success.html"
          },
          {
            "name": "Northwest Territories",
            "grade": "",
            "detail": "Cirque of the Unclimbables",
            "note": "",
            "url": "words/cirque-of-the-unclimbables-2023-climb-and-packraft.html"
          }
        ]
      }
    ],
    "header": {
      "image": "images/header.jpg",
      "focus": "center 55%",
      "credit": "Photo · Chase Hathaway"
    }
  },
  "home": {
    "kicker": "Christian Black",
    "title": "",
    "positioning": "Rock and alpine climber, writer, photographer and storyteller",
    "intro": "Christian Black is a multidisciplinary climbing athlete with an equal passion for storytelling and documenting. He enjoys contributing to his audience through [video](media.html), capturing a moment in a [photo](photography.html), or reflecting on an experience through his [writing](journal.html). His current focuses are big-wall free climbing and adventure paragliding.",
    "header": {
      "image": "images/header.jpg",
      "focus": "center 45%",
      "credit": ""
    },
    "proof": [
      {
        "value": "First ascent",
        "label": "White Sapphire, 6,040m — Kishtwar, India",
        "note": "AI3 M7+, 850m. American Alpine Journal, 2024"
      },
      {
        "value": "Big-wall free climbing",
        "label": "Golden Gate, 5.13a, El Capitan — ground-up free ascent",
        "note": "36 pitches, Yosemite"
      },
      {
        "value": "Para-alpinism",
        "label": "Climb and fly in the Cordillera Blanca, Peru",
        "note": "Cross Country Magazine, issue 265"
      }
    ],
    "reach": [
      {
        "value": "25k",
        "label": "Film views",
        "note": "All Grown Up - Dirtbag Fund film"
      },
      {
        "value": "Published work",
        "label": "Published in",
        "note": "AAJ - Climbing Mag - XC Mag - Gear Junkie"
      },
      {
        "value": "201k",
        "label": "Instagram views",
        "note": "90 days, 3k followers"
      }
    ],
    "cta": {
      "blurb": "for inquiries, media requests, licensing or collaboration"
    },
    "proofLabel": "Climbing",
    "reachLabel": "Reach"
  },
  "mediakit": {
    "kicker": "Media kit",
    "title": "",
    "lede": "",
    "header": {
      "image": "images/about-backdrop.jpg",
      "focus": "center 45%",
      "credit": ""
    },
    "bio": "",
    "audience": "",
    "reach": [
      {
        "value": "",
        "label": "",
        "note": ""
      },
      {
        "value": "",
        "label": "",
        "note": ""
      },
      {
        "value": "",
        "label": "",
        "note": ""
      },
      {
        "value": "",
        "label": "",
        "note": ""
      }
    ],
    "services": [
      {
        "name": "",
        "detail": ""
      },
      {
        "name": "",
        "detail": ""
      },
      {
        "name": "",
        "detail": ""
      }
    ],
    "partners": [
      {
        "name": "",
        "detail": ""
      }
    ],
    "downloads": [
      {
        "label": "",
        "url": ""
      }
    ]
  },
  "photography": {
    "kicker": "Photography",
    "title": "Photography",
    "lede": "Climbing, alpine and travel photography by Christian Black.",
    "working": "[Email](mailto:cblack9488@gmail.com) for licensing or assignments",
    "sets": [
      {
        "id": "climbing",
        "label": "Climbing"
      },
      {
        "id": "moments",
        "label": "Moments"
      },
      {
        "id": "places",
        "label": "Places"
      },
      {
        "id": "",
        "label": ""
      }
    ],
    "banner": {
      "image": "images/photography-banner.jpg",
      "headline": "Coming soon",
      "focus": "center 50%",
      "credit": "Photo · Christian Black"
    },
    "photos": [
      {
        "src": "images/photography/bmx-trick-mountain-store.jpg",
        "set": "moments",
        "full": "images/photography/bmx-trick-mountain-store-full.jpg",
        "caption": "KC and four Matts",
        "meta": "Tuolumne Meadows, CA",
        "alt": "Tuolumne grill, bmx bix, jumping friends, tuolumne meadows grill"
      },
      {
        "src": "images/photography/climber-golden-granite.jpg",
        "set": "climbing",
        "full": "images/photography/climber-golden-granite-full.jpg",
        "caption": "Matt Peña on his route Rolling Palms, 5.13d",
        "meta": "Tuolumne Meadows, CA",
        "alt": "Matt Peña, tuolumne meadows, climbing"
      },
      {
        "src": "images/photography/beach-runner-bw.jpg",
        "set": "places",
        "full": "images/photography/beach-runner-bw-full.jpg",
        "caption": "",
        "meta": "Biarritz, France",
        "alt": "Black and white view from above of a lone figure walking along the surf line, Biarritz france"
      },
      {
        "src": "images/photography/granite-face-in-cloud.jpg",
        "set": "places",
        "full": "images/photography/granite-face-in-cloud-full.jpg",
        "caption": "El Capitan",
        "meta": "Yosemite, CA",
        "alt": "A vast granite face half-hidden in cloud with a bird gliding across it"
      },
      {
        "src": "images/photography/rainbow-desert-highway.jpg",
        "set": "places",
        "full": "images/photography/rainbow-desert-highway-full.jpg",
        "caption": "Road home",
        "meta": "Basalt, NV",
        "alt": "A full rainbow arcs over an empty desert highway at sunset"
      },
      {
        "src": "images/photography/climber-overhead-reach.jpg",
        "set": "climbing",
        "full": "images/photography/climber-overhead-reach-full.jpg",
        "caption": "Matt Peña on his route Rolling Palms, 5.13d",
        "meta": "Tuolumne Meadows, CA",
        "alt": "Matt Peña, tuolumne meadows, climbing"
      },
      {
        "src": "images/photography/metro-tunnel-bw.jpg",
        "set": "moments",
        "full": "images/photography/metro-tunnel-bw-full.jpg",
        "caption": "Waiting",
        "meta": "Barcelona, Spain",
        "alt": "Black and white: a lone figure waiting on a bench in a long underground tunnel"
      },
      {
        "src": "images/photography/tuolumne-climber-red.jpg",
        "set": "climbing",
        "full": "images/photography/tuolumne-climber-red-full.jpg",
        "caption": "Carlin Reynolds on Yabo Yes",
        "meta": "Tuolumne Meadows, CA",
        "alt": "A climber in a red jacket on an orange granite wall. Carlin Reynolds climbing"
      },
      {
        "src": "images/photography/bubbles-plaza-bw.jpg",
        "set": "moments",
        "full": "images/photography/bubbles-plaza-bw-full.jpg",
        "caption": "Jumping for joy",
        "meta": "Barcelona, Spain",
        "alt": "Black and white street scene of children chasing giant soap bubbles along a palm-lined plaza"
      },
      {
        "src": "images/photography/glacier-camp-alaska.jpg",
        "set": "moments",
        "full": "images/photography/glacier-camp-alaska-full.jpg",
        "caption": "Kara's bubbles",
        "meta": "Pika Glacier, AK",
        "alt": "A figure in a patterned jacket blowing bubbles on a glacier"
      },
      {
        "src": "images/photography/furnace-night-work.jpg",
        "set": "moments",
        "full": "images/photography/furnace-night-work-full.jpg",
        "caption": "Fire and brimstone",
        "meta": "Tuolumne Meadows, CA",
        "alt": "pulling a pizza from a pizza oven, tuolumne meadows, california"
      },
      {
        "src": "images/photography/climber-pink-steep.jpg",
        "set": "climbing",
        "full": "images/photography/climber-pink-steep-full.jpg",
        "caption": "Matt Peña on his route Rolling Palms, 5.13d",
        "meta": "Tuolumne Meadows, CA",
        "alt": "Matt Peña, tuolumne meadows, climbing"
      },
      {
        "src": "images/photography/porter-mountain-town.jpg",
        "set": "moments",
        "full": "images/photography/porter-mountain-town-full.jpg",
        "caption": "Basket carrier",
        "meta": "Badrinath, Uttarakhand, India",
        "alt": "A porter carrying a loaded basket through the market street of a mountain town"
      },
      {
        "src": "images/photography/harness-and-spire.jpg",
        "set": "climbing",
        "full": "images/photography/harness-and-spire-full.jpg",
        "caption": "Guillaumet Rodeo",
        "meta": "Patagonia, Argentina",
        "alt": "summit of Guillaumet, patagonia argentina"
      },
      {
        "src": "images/photography/tuolumne-climber-sunset.jpg",
        "set": "climbing",
        "full": "images/photography/tuolumne-climber-sunset-full.jpg",
        "caption": "Jake Squier on The Seamster",
        "meta": "Tuolumne Meadows, CA",
        "alt": "Jake squier climbing in Tuolumne meadows, california"
      },
      {
        "src": "images/photography/dancer-night-bw.jpg",
        "set": "moments",
        "full": "images/photography/dancer-night-bw-full.jpg",
        "caption": "Groove",
        "meta": "Salt Lake City, UT",
        "alt": "Black and white: a dancer caught mid-movement under low light of a disco ball"
      },
      {
        "src": "images/photography/hikers-toward-peak.jpg",
        "set": "places",
        "full": "images/photography/hikers-toward-peak-full.jpg",
        "caption": "",
        "meta": "Patagonia, Argentina",
        "alt": "Guilllaumet, Patagonia argentina"
      },
      {
        "motion": true,
        "src": "images/photography/glacier-camp-loop.jpg",
        "set": "moments",
        "mp4": "images/photography/glacier-camp-loop.mp4",
        "webm": "images/photography/glacier-camp-loop.webm",
        "caption": "Pika spika",
        "meta": "Pika Glacier, AK",
        "alt": "A short loop of a volleyball game played on the glacier at camp, below a rock peak"
      },
      {
        "src": "images/photography/figure-rusted-platform.jpg",
        "set": "moments",
        "full": "images/photography/figure-rusted-platform-full.jpg",
        "caption": "Content - Alfonso Ventimilla",
        "meta": "Lobitos, Peru",
        "alt": "Looking down at a person resting on a rusted metal platform with gear scattered around"
      },
      {
        "src": "images/photography/tuolumne-slab-climber.jpg",
        "set": "climbing",
        "full": "images/photography/tuolumne-slab-climber-full.jpg",
        "caption": "Carlin Reynolds",
        "meta": "Tuolumne Meadows, CA",
        "alt": "Carlin Reynolds climbing in Tuolumne Meadows, California"
      },
      {
        "src": "images/photography/museum-dark-figure.jpg",
        "set": "moments",
        "full": "images/photography/museum-dark-figure-full.jpg",
        "caption": "MACBA",
        "meta": "Barcelona, Spain",
        "alt": "Skateboarder doing a kickflip in front of the MACBA museum, barcelona spain"
      },
      {
        "src": "images/photography/belayer-yellow-jacket.jpg",
        "set": "climbing",
        "full": "images/photography/belayer-yellow-jacket-full.jpg",
        "caption": "Sauerkraut snackin' ",
        "meta": "Tioga Cliff, CA",
        "alt": "A belayer in a yellow jacket eating a snack while belaying"
      },
      {
        "src": "images/photography/alpine-ridge-sunburst.jpg",
        "set": "climbing",
        "full": "images/photography/alpine-ridge-sunburst-full.jpg",
        "caption": "Alpamayo summit",
        "meta": "Cordillera Blanca, Peru",
        "alt": "A climber on a corniced snow ridge with the sun bursting over the peaks behind. Alpamayo summit in the Cordillera Blanca"
      },
      {
        "src": "images/photography/wall-jump-village.jpg",
        "set": "moments",
        "full": "images/photography/wall-jump-village-full.jpg",
        "caption": "Alfonso Ventimilla",
        "meta": "Lobitos, Peru",
        "alt": "A skateboarder doing a trick in front of a green wall in Lobitos, Peru."
      },
      {
        "src": "images/photography/alpine-granite-buttress.jpg",
        "set": "climbing",
        "full": "images/photography/alpine-granite-buttress-full.jpg",
        "caption": "Surya Kund basecamp",
        "meta": "Badrinath, India",
        "alt": "A rock climber climbing a route in Surya Kund basecamp, India"
      },
      {
        "src": "images/photography/paraglider-dusk.jpg",
        "set": "places",
        "full": "images/photography/paraglider-dusk-full.jpg",
        "caption": "Summer skies",
        "meta": "Esquel, Argentina",
        "alt": "A paraglider silhouetted against an orange sky above dark ridgelines at dusk"
      },
      {
        "motion": true,
        "src": "images/photography/hulk-milky-way.jpg",
        "set": "places",
        "lead": "places",
        "mp4": "images/photography/hulk-milky-way.mp4",
        "webm": "images/photography/hulk-milky-way.webm",
        "mp4Large": "images/photography/hulk-milky-way-2560.mp4",
        "webmLarge": "images/photography/hulk-milky-way-2560.webm",
        "caption": "The Incredible Hulk",
        "meta": "Sierra Nevada, CA",
        "alt": "A timelapse of the Milky Way wheeling above a dark granite ridge"
      },
      {
        "src": "images/photography/climber-high-reach.jpg",
        "set": "climbing",
        "full": "images/photography/climber-high-reach-full.jpg",
        "size": "full",
        "caption": "Sarah Fenoglio on The Other, 14a",
        "meta": "Las Vegas, NV",
        "alt": "A climber in a yellow top reaching high on an overhanging wall, the rope running down to a quickdraw"
      },
      {
        "src": "images/photography/climber-overhead-crimp.jpg",
        "set": "climbing",
        "full": "images/photography/climber-overhead-crimp-full.jpg",
        "caption": "Rachel Melville on Glory Crack, 13c",
        "meta": "Las Vegas, NV",
        "alt": "Looking straight down on a climber pulling hard on a steep limestone wall, the ground far below"
      },
      {
        "src": "images/photography/climber-under-roof.jpg",
        "set": "climbing",
        "full": "images/photography/climber-under-roof-full.jpg",
        "caption": "Sarah Fenoglio on The Other, 14a",
        "meta": "Las Vegas, NV",
        "alt": "A climber stretched out beneath a wide overhanging roof above a rocky landing"
      },
      {
        "src": "images/photography/limestone-wall-evening.jpg",
        "set": "climbing",
        "full": "images/photography/limestone-wall-evening-full.jpg",
        "caption": "The Roost",
        "meta": "Las Vegas, NV",
        "alt": "A lone climber high on a huge golden overhanging wall in evening light, pines on the slope below"
      }
    ]
  },
  "journal": {
    "kicker": "Journal",
    "title": "Journal",
    "lede": "Essays, trip reports, techniques, and beta",
    "entries": [
      {
        "id": "garhwal-himalaya",
        "title": "Failure or success? A trip to the Garhwal Himalaya",
        "date": "",
        "dateLabel": "",
        "meta": "Trip report",
        "lede": "",
        "cover": "images/words-second.jpg",
        "thumb": "images/words-second.jpg",
        "credits": [],
        "pullquote": "",
        "comingSoon": true,
        "body": ""
      },
      {
        "id": "fight-or-flight",
        "title": "Fight or Flight",
        "date": "2025-08-01",
        "dateLabel": "August 2025",
        "meta": "Feature",
        "lede": "Para-alpinism in the Cordillera Blanca.",
        "cover": "images/journal/fight-or-flight/01.jpg",
        "credits": [
          "By Christian Black"
        ],
        "pullquote": "",
        "body": "I am at almost 19,000ft. My wing is unfurled on the snow in front of me catching drifts of the thin Andean air coming over the ridge. Behind it is a cliff heading to the bottom of the southeast face of Artesonraju, the half of which we just climbed. Behind me is another cliff tumbling off the southeast ridge where Rowan and I stand on a slope just barely large enough to lay out our small descent paragliders. It is large enough to launch but certainly not large enough to mess up. Rowan has me on a makeshift belay while I gather my footing and ready to pull up my wing into the wind. It is a belay in the sense that there is a rope attached to me, but makeshift in the sense that we just made this system up. I have never heard of someone launching a paraglider “on belay” before. It is untested but it provides us with a feeling of added safety during the transition from ground to sky in case of a slip during launch. I tug on my risers to bring the wing up, letting my body control the glider in the way it knows how. My mind goes blank. Numb.\n\nThe misnomer “adrenaline junky” is often applied to those who do risky sports. Indeed that may be the case if you do them irresponsibly, but any adventure athlete will tell you that stillness of the mind characterizes safety and control. It is an override of the body telling the mind that it is unsafe. And indeed, to perform our best, even perfectly at times, we cannot listen to the mind, only perform with the body. “Flow state” as it is called. An incredibly useful adaptation that can be learned to overcome our fight or flight nervous system response to danger.\n\n[photo: images/journal/fight-or-flight/02.jpg]\n\nIt is this that I feel when my wing comes overhead and I turn around to prepare to run off of our icy pedestal into thin air under the support of my nylon aircraf. Or rather, it is precisely what I don’t feel.\n\nRowan and I had come to Peru with a seemingly simple plan. Explore the Cordillera Blanca for its potential paragliding and climbing, using the paraglider as either a descent tool or a way to arrive deep into the mountains using thermals to turn days worth of approaching in mere hours of flight. While simple in theory, the reality of doing this safely would be a much different undertaking. Unlike in the U.S., there are no weather stations in the Cordillera Blanca to ground-truth and provide data to high resolution weather models. Being in the southern hemisphere there are also many less models to reference for forecasting in the first place. Instead, we would have to build our own models, mentally, of the patterns, strengths, directions and schedule of the winds, ground-truthing our guesses with observations as we hiked, acclimatized and climbed in the range each outing. The only pieces of the puzzle we had were the edges - maps. With satellite imagery and topo maps we could make calculations about where we could land if we launched from certain peaks and dream up ideas for using the terrain and thermals to arrive at basecamps in an hour what would normally take 2-3 days on foot. And so we began our grand puzzle with no picture to reference. We would find out what the picture was with enough time and effort.\n\n[photo: images/journal/fight-or-flight/03.jpg]\n\nThe first pieces of the puzzle began falling into place during our acclimatization outings. From the large-scale wind forecast, we knew there was an east wind hitting the range every morning, but we didn’t know how strong it was. From our best guess, this was the movement of the large, wet airmass sitting over the amazon rainforest just to the east of the Cordillera Blanca. Each morning when the sun hits the east faces of the 20,000ft+ mountains, the heated air rises and expands, creating low pressure and drawing in the dense air from the Amazon to replace it. The draw quite literally sucks air from the east as it spills over the passes and onto the peaks of the Cordillera.\n\nWe needed to acclimatize, and we also needed to figure out the timing and strength of the east wind to understand if early morning would be a launchable window or not. Two outings would cement our understanding of this weather pattern.\n\n[photo: images/journal/fight-or-flight/04.jpg]\n\nThe first came when Rowan was able to launch from the summit of Yannapaccha at 5400m at 8:30am while I nursed a splitting altitude headache on the hike down from basecamp. Early in the morning the clouds are not as high as they are in the afternoon, a fact Rowan had to deal with as he sat on the summit amidst cloud level waiting for a clearing to launch before taking off in a “much stronger than desirable” east wind.\n\nThe second data point came during a solo acclimatization hike and fly from the summit of Vicos peak at 5400m, where I found an overcast sky at 8am on the summit and zero wind. The low overcast clouds had shaded out the entire range, cutting off the “draw” effect of the east wind due to lack of solar heating. The still air provided quick relief in the form of a 15 minute flight from the summit to land 200 meters from my stashed motorcycle at the trailhead.\n\n[photo: images/journal/fight-or-flight/05.jpg]\n\nWith both outings we learned similar lessons; we would have to avoid starting our climbs from a traditional high climbing basecamp if we wanted to climb and fly anything technical simply because high camps are typically talus fields at the base of glaciers, aka, un-landable. If we wanted to land at a low camp grassy field, we either needed to start our day from there, or carry a full bivy kit plus wings up and off the climb. Para-alpinism was suddenly heavier than I wanted it to be.\n\nAnother data point came on the first day of the trip during a cross-country flight from a local launch we found scouring online maps. What started as an easy flight turned potentially sour fast as I came in to land in the town of Yungay 20km to the south. The wind on the ground was faster than my wing could fly, meaning I was going backwards into a smaller-than-desirable soccer field. I was not so uncertain I would miscalculate the landing and end up tangled on a rooftop or a plethora of other agriculture-related hazards surrounding me. During the last couple critical minutes of descending backwards, my mind switched from a light panic once again to a total calm.  A familiar numbness as my body overrode the fight or flight response yet again.\n\n[photo: images/journal/fight-or-flight/06.jpg]\n\nUpon my safe landing I would also find the soccer field was in a police academy, as I was promptly swarmed by curious officers.\n\nDuring both of these experiences, a directed effort to mute the mind and pause the flow of feelings from the body to the brain had provided safety in the moment. In fact, I was so used to this nervous system pathway re-route from over a decade of climbing and other high-risk sports that I was quite good at it. It was a default headspace, even. But during rest days between outings into the mountains and between many difficult conversations via a budding new relationship, it became abundantly clear that blocking out my feelings was only an advantage in certain contexts. What protected me in the mountains left me helpless, confused, and unpracticed at naming my complex emotions in other facets of my life. In fact, during the most difficult of conversations my actual fight or flight response would turn on, and I would feel my brain simply click off and flatline as it struggled to process an overload of emotions.\n\n[photo: images/journal/fight-or-flight/07.jpg]\n\nBack on the edge of Artesonraju, however, I was glad to feel the numbness and let my body take over as my wing came steadily overhead and Rowan released the belay holding me to the mountain. I was glad to feel in control as I slid off the southeast ridge into the hands of the wind to take me home. I was glad for an easy escape into the sky to avoid a downclimb and descent I had no energy for. And upon landing at Laguna Paron 12 minutes later, I was most glad to see Rowan’s wing come up and off the mountain, a task he volunteered for without the belay.\n\nThe one thing I was not glad about once safe on the ground was the lingering question in the back of my mind. Did we just get away with something? Was that too far? Or did we nail it? I couldn’t decide where the line was for me. In one sense it was a great success in using our paragliders in a meaningful way to teleport from high on a peak to the safety of basecamp in a matter of minutes. On the other hand it felt like a failure because I felt woefully unprepared with enough energy, food, or both to downclimb and slog out of there on foot had the winds not been just right. We had escaped the mountain, yes, but in the process shirked the responsibility we owed to ourselves for our plan not to work. Flight.\n\n[photo: images/journal/fight-or-flight/08.jpg]\n\nAfter a break from the mountains for a week, we geared up for a final outing to climb Alpamayo’s famous southeast face. We had hoped to skip the 2-3 day approach to basecamp in place of a short 20km thermal flight, and even had some success earlier in the trip finding a suitable launch and scouting a line in the sky through the mountains that could take us to basecamp. On our second attempt, I even got so far as climbing to cloud base in my paraglider at 5700 meters with Alpamayo in sight a short 20km flight away, my harness full with 3 days of food, bivy gear and climbing gear. Rowan, unable to arrive as high as me to attempt our flight route, had to land early and we therefore abandoned that attempt for the trip. Another piece of the puzzle uncovered at least.\n\nThis time we instead slogged into Alpamayo basecamp via the usual route with mules through the Santa Cruz valley, taking notes of the wind speeds and directions through the valley to add into our mental model. Of course we carried our small paragliders as well, hoping to fly from the summit of Alpamayo if conditions aligned; it had only been done for the first time the year before. Soon enough, we were at high camp at 18,000ft, waking up at 11pm to begin our night climb of the French Direct, paragliders in our packs and hopes for light summit winds in our minds.\n\n[photo: images/journal/fight-or-flight/09.jpg]\n\nThis time, however, I wanted to be prepared for our plan to fail. Our plan being to either fly from the summit or at least fly down from high camp to basecamp. We carried enough food in case none of the flights were possible and we might need to simply get out the old fashioned way. The extra supplies meant added weight to our packs, but really represented shouldering the responsibility to be self sufficient and not rely on our nylon escape plan. We were starting to learn at least.\n\nAt 6:45am we crested the final moves onto the summit ridge of Alpamayo, having enjoyed a long simul climb up the perfect runnel of snow and ice characteristic of the peak. Our first impressions on the summit ridge immediately aligned. The winds were already too strong. The summit ridge was too small. We traversed 50m along the corniced ridge to a flatter spot to re-assess. Maybe a belayed launch would work if the winds died down, but they were seemingly only increasing. It was far above what we considered reasonable to even attempt, but at least we were in agreement. We would not be flying down.\n\n[photo: images/journal/fight-or-flight/10.jpg]\n\nThroughout the trip Rowan and I had learned to trust each other, talking through our ideas of how the wind systems were working, planning outings, and debriefing successes and failures. We knew an exploratory trip like this would lead to some failures, but to us success meant going home in one piece, hoping to have learned something in the process. More importantly though we had to learn to trust ourselves, trust our assessments of the conditions, and trust our motivations. We needed to be exploring the para-alpinism opportunities because we were genuinely curious, not for an extrinsic reason that could cause us to try something that might kill us for clout. The ground-truthing we had been doing all season was really an internal reflection of our motivational process, making sure we could make good decisions for the right reasons. And today, that reason meant abandoning a pipe dream of flying off the summit of Alpamayo. And that was okay.\n\nGround-truthing is not only a useful way to gather data for paragliding, but also an internal process I am learning I need to work on within myself. To check in with myself, with my motivations, with my pains or fears is an act of care I owe to myself. It is the antithesis of fight or flight. It is be and feel. It is the opposite of the numbness that can keep me safe in the mountains, and it is a switch, or rather a dial, I am still learning to tune.\n\n[photo: images/journal/fight-or-flight/11.jpg]\n\nIt is said “...land is always in the minds of the flying birds”. Ironically, through flight, I am learning to be grounded.",
        "thumb": "images/journal/fight-or-flight/08.jpg",
        "related": [
          {
            "label": "See the publication",
            "url": "https://xcmag.com/magazine-articles/adventure-and-inspiration/fight-or-flight/",
            "note": "Cross Country Magazine, issue 265"
          },
          {
            "label": "Listen to the story",
            "url": "https://xcmag.com/podcasts/the-paragliding-podcast-episode-5/",
            "note": "The Paragliding Podcast"
          },
          {
            "label": "Watch the excerpt",
            "url": "https://www.youtube.com/shorts/UHOrrVIFSto",
            "note": "Cross Country Magazine"
          }
        ]
      },
      {
        "id": "the-golden-handcuffs",
        "title": "The Golden Handcuffs",
        "date": "2024-06-01",
        "dateLabel": "June 2024",
        "meta": "Essay",
        "lede": "",
        "cover": "images/journal/the-golden-handcuffs/01.jpg",
        "credits": [
          "Written by: Christian Black"
        ],
        "pullquote": "",
        "body": "A reflection of years spent in Yosemite Valley and working through identity while climbing Golden Gate\n\nThis essay is a reflection of my personal experience, and is not necessarily meant to speak for others. If it resonates with others, I hope it can offer some comfort in a shared experience.\n\nI have given Yosemite years of my life, building myself into the climber I wanted to be. It is the place in which I first “found myself.” I had put in the hard work to become a Yosemite climber, having escaped my Texas roots in an effort to become someone new. I lived my own dream, becoming a member of the Search and Rescue team for two seasons, and finally reaching my dream job as a climbing ranger in the mecca of the climbing world. I belonged. Yet, at the prime of my years working there, I felt for the first time the slow grip of the golden handcuffs that Yosemite so graciously gifts those who choose to make a life there. This is the term often used by the returning inhabitants to Yosemite Valley.\n\nThe Golden Handcuffs are my closest friends. They are afternoons lounging in meadows. They are the crisp water of the Merced on my sun-baked body, the evening glow of sunset on El Cap, and the drone of waterfalls that lull me to sleep. The Golden Handcuffs leave me sore after a run in the High Sierra, elated on a climb high above the valley floor, and satiated by a community. They are paradise. Golden.\n\n[photo: images/journal/the-golden-handcuffs/02.jpg]\n\n[photo: images/journal/the-golden-handcuffs/03.jpg]\n\n[photo: images/journal/the-golden-handcuffs/04.jpg]\n\n[photo: images/journal/the-golden-handcuffs/05.jpg]\n\nIt is only upon leaving each season that I felt the tightening click of the handcuffs. A sense of lostness each fall as I decided where to go. Click . A longing for home that I only found in my friends, each now dispersed into the wind for the next six months. Click . Most apparent though, a deep questioning of who I was outside of this place. Click click . I struggled to understand my identity outside of the tight-knit world of the Yosemite climbing community. Not because we are necessarily defined by our climbing acheivements, but because climbing draws upon a vulnerable and authentic energy that is seen, deeply seen, by your peers. It was the struggle of going from known to unknown . I coasted without myself until I could return each spring.\n\nWhile I was growing as a climber in Yosemite, after some time, I began to feel stagnant as a person. I knew Yosemite was not a forever home and I felt ill-equipped to transition into the real world. How else could I use my skills and experiences learned here? I struggled to find ways to apply my Yosemite experience to anything other than climbing itself. I didn’t know the answer, but I also knew I wouldn’t find it if I stayed.\n\nIt is an uncomfortable feeling to reject a place that has given you so much, but growth comes from uncomfort. If there is anything I have learned through climbing, it is how to be uncomfortable. The tough decision to leave, to face my identity outside of Yosemite, began an almost three year hiatus from this place in which I learned to love it from afar, dreaming to return as a new, fuller version of myself.\n\nAnd so began the great experiment. Can I spend time away from this place to expand and explore other areas of my life, and still become capable of fulfilling a lifelong dream to free climb El Cap? Fast forward through three years of experimentation in the great game of life, figuring out where I wanted to go and who (else) I wanted to become as a person. Trips to Mexico, Colombia, Alaska, Canada, Spain, and India continued to shape and grow me as a climber. I continued growing in my field biology work. I experienced an amazing and fulfilling romantic relationship. I experimented with finding a home base, and finally settled into an amazing community in Salt Lake City. I even hired a climbing coach and began to train seriously for the first time.\n\nThe test now was to come back to Yosemite, three years later, to see if I had also become the climber I wanted to be.\n\nIt seemed the answer was no.\n\n* * *\n\n[photo: images/journal/the-golden-handcuffs/06.jpg]\n\nScott Bennett warming up for the Golden Desert pitch\n\nScott Bennett and I had teamed up for an effort on Golden Gate, both of our original partners unfortunately suffering from injuries and having to bail. I had met Scott through mutual friends but we instantly got along. Aside from a legendary climbing resume including Cerro Torre, new alpine routes in the Himalayas, or three El Cap routes in a day, Scott is known above all for being incredibly kind. His positive attitude and authentic friendliness are immediately apparent. When Scott texted me looking for a partner for Golden Gate just half an hour after my partner and I had bailed from our start on the route I immediately said yes.\n\nIt was now day ten on a ground-up* effort at freeing Golden Gate, the previous nine days having sapped every ounce of energy to red-point through each of the crux pitches below. On day three we had sent the first of the hardest pitches, T he D ownclimb , but another three days of effort would be required before finally red-pointing The Move pitch on day six. The fatigue was compounding, and after two more days of lead efforts Scott and I chose to top-rope the Golden Desert pitch on day eight and move on to the final crux pitch. Fifty feet of traversing on sloping holds and small feet marked the last of the hard climbing on the route, and in a proud effort Scott polished off his send of the A5 T raverse on the morning of day nine. Out of food, we climbed to the summit to retrieve a final day's worth of food brought to us by a friend and sle pt on top . The morning of day ten we rappelled back in to the A5 Traverse so I could have one more chance at the only section of route I had yet to free-climb.\n\n[photo: images/journal/the-golden-handcuffs/07.jpg]\n\n[photo: images/journal/the-golden-handcuffs/08.jpg]\n\n[photo: images/journal/the-golden-handcuffs/09.jpg]\n\n[photo: images/journal/the-golden-handcuffs/10.jpg]\n\nBut now I found myself slumped in my harness, hanging from the rope on the A5 traverse . Two failed attempts have left me exhausted, drained, wanting to cry. My elbows ache from tendonitis and I feel like sleeping for two weeks. Five feet of climbing separate me from my decade-long dream of free climbing El Cap, but my body has nothing left to give.\n\nScott encourages me to give it one more go. He believes I can do it, I remain unconvinced. As I summon the energy for a final try, I look around for my good-luck charm, the peregrine falcon nesting nearby. It is nowhere to be found. I make my way to the start of the pitch, feeling heavy with anxiety and mind-numbing exhaustion.\n\nI start up the opening moves to a rest and begin to reflect on my experience. “ Have I come all this way, gotten this close, just to fail on the final five feet of climbing? Maybe I have not become who I wanted to be ”. I felt the familiar click of the golden handcuffs, and it dawned on me. After all these years away, I still had a portion of my identity tied to success in this place.\n\nA moment of clarity struck me. It is unimportant whether or not I send, that has no reflection on my character. My character is shown through my relationships with friends and family, how I treat people, my attitudes, my actions. I will not be anybody different by doing this rock climb. Who I do want to be though, for myself, is a person who finds joy in trying, regardless of the outcome. That is enough for me.\n\n[photo: images/journal/the-golden-handcuffs/11.jpg]\n\nI felt my mind ease, finally, from the burden I had been putting on myself. The key to the golden handcuffs finally twisted into the lock and released. Moments I barely remember pass as my body executes the well-rehearsed dance of final moves, coming-to as I reach up to grab the final hold.\n\nFor the first time on a climb, I broke down into tears. Tears of relief, disbelief, and, strangely, a form of sadness that it was over.\n\nI had crossed through my own golden gate, one that made me realize that the simple effort of trying is what made me who I wanted to be.\n\nBack to the question of how to apply my Yosemite experience to the outside world. I don’t think there is a ubiquitous answer, but what I have taken most from my time in Yosemite is the skill of knowing myself, confidently, in a way that I did not before. To know what a good friend is, to know how to recognize a beautiful place, to know that I am capable of trying, hard, for things I care about. This is what I carry forward from Yosemite."
      },
      {
        "id": "brilliant-blue-first-all-american-expedition-to-india-s-kish",
        "title": "Brilliant Blue",
        "date": "2023-10-01",
        "dateLabel": "October 2023",
        "meta": "Trip report",
        "lede": "",
        "cover": "images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/01.jpg",
        "credits": [
          "Drafted from the entry in the 2024 American Alpine Journal",
          "Written by Christian Black, edited with help of Matt Samet. Photos by Vitaliy Musiyenko.",
          "Team: Christian Black, Hayden Wyatt, Vitaliy Musiyenko"
        ],
        "pullquote": "",
        "body": "Friendship and Success on White Sapphire peak (6,040 meters), an American expedition to India's Kishtwar Valley\n\nAmerican Alpine Club Cutting Edge Podcast Interview HERE\n\nRead the American Alpine Club Q&A interview HERE\n\nIn early September of 2023, myself, Hayden Wyatt, and Vitaliy Musiyenko set off from the Salt Lake City airport with 400 pounds of gear and a crippling curiosity. I had forfeited my season of field-biology work for another international trip, a now-common trend that continued to sabotage my personal finances. Hayden, having never even met Vitaliy, took a semester off law school in Portland to join. Vitaliy, too, shortly after his honeymoon, packed his bags and took time off from his job as an ER nurse to commence his second long expedition in one calendar year. These were all significant sacrifices considering our inspiration had been sparked solely by two blurry photos of an unclimbed line on a Himalayan peak in India’s Kishtwar Valley. The grand range was a place Vitaliy had dabbled in, but that Hayden and I had only dreamt of. As the plane took off from our home base in SLC, I contemplated the absurdity of events that had brought us here.\n\nA climbing trip to Mexico years ago had led to a fruitful connection with new mutual friends, through whom I’d met the infamous seasoned-alpinist-turned-sport-climber , Pete Takeda. Pete and I linked up for another sport-climbing trip to Spain the following year, during which he offhandedly probed my interest in a potential new route on a 6,040-meter Himalayan mountain called the White Sapphire, a gem he’d been keeping in his back pocket for years. When prodded further, Pete produced a few blurry photos of a diamond-shaped peak hosting a stunning, 2,700-foot unclimbed northwest face. Pete, happy to pass the torch on this climb, offered to mentor on logistics, and he helped with the ins and outs of submitting for the Cutting Edge Grant. Months later, I received notice that we’d been awarded $8,000, and I phoned Hayden to tell him to change his summer plans. Now we were buckling our seatbelts to fly to India. Thanks, Hinge.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/02.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/03.jpg]\n\nOur Liaison Officer from the Indian Mountaineering Federation, Anant Singh\n\nAfter a twenty-eight-hour blur of travel, we were at the Indian Mountaineering Federation in chaotic Delhi, receiving our peak permit and meeting Anant, our liaison officer. Only twenty-one, he was bright-eyed and energetic, and exuded an excitement for the mountains that quickly resonated with us. Within five minutes of meeting him, he was showing us photos of beautiful peaks from previous expeditions, his aspirations for the high alpine impossible to miss.\n\nRoad weary from another eighteen hours of trains and taxis, we began our three-day trek to basecamp from the town of Gulabgarh in the foothills the following day. As the valleys deepened and we distanced ourselves from the roadhead, so finally did our minds begin to settle. The roar of the river accompanied the soundscape of pack-mules slowly ascending through the Kishtwar Valley. Halfway through our day, the deep greens, blues, and grays of the valley were suddenly replaced by vibrant pinks, oranges, and yellows. We were at the famously colorful Chandi Mata Temple in the village of Machail, where, each August, thousands of Hindus come during the Machail Yatra holy pilgrimage. Following the lead of our logistics organizer, we, too, bowed in front of the temple to ask for blessings and safe passage.\n\nThe next morning, we reached a prominent split in the valley, demarcated by the towering peak of Kishtwar Shivling in the middle, so named for the three rock spires on its shoulder resembling Lord Shiva’s trident. The valley south of Shivling hosted the home village of one of our basecamp cooks, Stenzing. The valley just north was our route to Hapital Glacier and our basecamp below White Sapphire Peak. Farther north yet was the valley where the famously blue Kashmiri sapphires the region is known for are mined.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/04.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/05.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/06.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/07.jpg]\n\nWe rounded a bend and came upon a skyline familiar to us from Pete’s two blurry photos. The centerpiece, Cerro Kishtwar, looked like a dorsal fin penetrating the sky as if it were the surface of the water. Just to the south, at the farthest end of the valley, was White Sapphire, an aptly named peak with a gemlike shape and angular features. The peak had only had two ascents to date. The first was La Virée des Contemporains (850m, WI5 with two crux pitches of WI6, M6, and A2), via Stefan Siegrest and Denis Burdet on the west face in 2011. The second , in 2015, also by a Swiss team, accessed the White Sapphire via the southeastern aspect, climbing mostly moderate ice and mixed terrain along the south ridge to the summit. Our aspirations lay in the 2,500-foot unclimbed big wall on the northwest face, but we knew we would have to be flexible considering our late-season start.\n\nFast forward one week to mid-September. We were already conducting our first bit of alpinism—sitting stormbound in a bivy tent through forty-eight hours of rain at 14,500 feet on our way to establish an advanced basecamp (ABC). Our efforts of hiking loads had been put on pause, to be replaced by the softer skills of alpinism: reading, eating chocolate butter, and having horizontal dance parties to whatever music was downloaded on our phones. When we finally emerged from our nylon coffins, a quick look to the skyline jarred our vision. Winter had arrived, with it killing our dream of wearing rock shoes on a big-wall climb, a reality we accepted as we donned our ice boots and continued hiking loads up to ABC at 15,800 feet.\n\nOne of the few benefits of hiking heavy backpacks up large hills is the ample time for reflection. As we wobbled up loose talus and weaved through crevasse fields, we couldn’t help but feel the juxtaposition of our current environment against each of our pasts. The Himalaya was about as far as you could get from the flat ranchlands of my North Texas upbringing, or the University of Texas rock gym where I’d begun my journey as a climber a decade earlier. Vitaliy was a city-raised immigrant to the United States from the Ukraine, and a former 300-pound high-school linebacker and Domino’s pizza boy. He’d escaped the box of his childhood via a slow boil of increasingly epic feats in the mountains, including the solo first ascent of the 32-mile alpine-rock Goliath Traverse in the Sierra Nevada. Hayden, on the other hand, took joy in finally participating in the high-alpine lore of his own childhood. He grew up to heroic tales told by his legendary , Tetons-based mountain-guide parents, Evelyn Lees and Rick Wyatt, who had ventured on expeditions to Nanga Parbat and the north face of Everest, to name a few. We reminisced about the absurdity of it all as we distracted our heaving lungs and anxious minds from the task at hand. To be present in these mountains was a privilege not lost on us. With each memory we shared of our pasts and each concern we voiced about our near future, we cultivated the bond between members of a new team that we’d need to rely on, high on the wall.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/08.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/09.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/10.jpg]\n\n“I’m 9/10 fucked right now. I can’t do it, Hayden. You gotta do it.”\n\nI handed Hayden the rack as I turned on my headlamp at our hanging ice belay near 19,200 feet. We had left ABC early that morning on two hours of poor sleep, having ascended the glacier to the start of the climbing at 17,200 feet. Due to the winter conditions, we’d bailed on our original plan of climbing the big-wall of the northwest face. Instead, we’d picked a logical line that followed an ever-steepening snow and ice gully cutting left of the northwest face; 2,000 feet up the wall, the gully ended in a notch in a ridge, where the remaining 650 feet of climbing followed steep rock along the north face to the summit.\n\nWhile only 50 feet of mixed climbing remained until our prospective bivy spot at the notch, the previous 15 hours of simul-climbing and the huge jump in elevation had left me fatigued on a whole, new level. Vitaliy, with his ultra-marathon-charged fitness, set the pace for the day as he and Hayden swung leads through the first 1,500 feet of steep snow and ice, all of us frequently pausing to sit out long spindrifts. After fighting through fatigue, I took over for two tricky mixed pitches nearing the notch, but as the sun disappeared below the horizon so did my remaining energy.\n\nTen-thirty p.m. rolled around and were finally sitting on a chopped-out snow bench after Hayden led that final pitch. Our prospective bivy site turned out to be much smaller than we’d hoped—it was a tiny, overhanging cornice just barely large enough to pitch our tent. With Vitaliy and I out of commission from frozen hands and exhaustion, Hayden stepped in to start organizing our gear and melting water. As I sat there, almost useless, I recognized that my entire life’s purpose had boiled down to a simple task: hold the stove upright , which I did for the next four hours as we sat there, eating and rehydrating. At 2:30 a.m. we settled into the tent, grateful to Hayden for keeping morale afloat through our evening.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/11.jpg]\n\nHayden leading the final pitch to the notch bivy around 10 p.m.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/12.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/13.jpg]\n\nSunrise woke us five hours later from our cramped slumber, our splitting headaches softened by our first eye-level view of the Himalaya. No longer were the surrounding peaks high giants—we had climbed up the beanstalk and were now among them. Cerro Kishtwar’s shark-fin of rock reared up to the north, now larger than ever. To the west lay Dandagoporum, an equally high peak with a razor-sharp ridge ascending over 5,000 feet to its summit. And to the northwest were the 3,000-foot big walls of the southeast face of Kishtwar Shivling.\n\nFrom our position in the notch, the only possibility of continuing up our giant was via the steep headwall of the north face, which led 650 vertical feet to the summit. The rock was not granite, as we had previously thought, but instead very compact gneiss with few cracks. We looked up with uncertainty. A featureless slab blocked the cracks above, which, while steep and sustained looking, appeared to take good gear. This was more like a rock climb than we’d imagined— climbing in boots and crampons. After a slow morning of good coffee and a concoction of altitude meds, my curiosity finally overcame my doubt and I volunteered to take the first lead.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/14.jpg]\n\nThe first pitch out of the notch bivy, a delicate M7+\n\nIn an effort to block out the crippling exposure, I let my childlike mind take over and began to tinker with the pointy bits of alpinism on the puzzle of rock in front me. I eventually found upward progress through a creative blend of aid and free climbing, linking shallow pins and thin edges. In that vein we proceeded upward, never certain of progress but never failing to find it either. By the end of the day, only 300 or so feet of headwall remained. As we fixed our ropes to descend to our bivy, we felt the tantalizing possibility of success.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/15.jpg]\n\nThe next morning, we awoke eager to complete our climb. Our morning coffee routine, however, was interrupted. Chhhk, chhhk, chhhk—Vitaliy flicked the lighter against the stove, to no avail.\n\nThe stove had slowly weakened during the climb, but this time we could no longer hear gas coming out despite the full fuel canister. We suspected it was related to the different fuel mix of canisters in India, causing our stove to overheat and a safety mechanism to melt and block the fuel lines. All attempts at stove surgery were thwarted by not having the right tools, and inReach advice from the outside world proved fruitless as well. With less than one liter of melted water between us, we accepted the crushing conclusion that continuing would be irresponsible and unsafe. High on a technical face at 19,000 feet was not the place to gamble with dehydration; our teamwork could not overcome this obstacle. We retrieved our ropes and, frustrated, rappelled 2,000 feet back to the glacier.\n\n****\n\nAfter three days resting in basecamp, we hiked back up to ABC with more food—and a backup stove. One more week of waiting for a weather window and we were soon simul-climbing the steep snow and ice back to our cornice bivy at 19,200 feet. It was much colder this time, and, despite the constant movement of simul-climbing, my layering failed to keep me warm. Fatigue and dehydration manifested as light nausea and uncontrollable shivering, forcing a pause midway through our day for hot fluids and forced calories. We continued, and with good pace arrived at our notch bivy just before sunset.\n\nWe awoke to perfect weather, the cloudless skies blanketing the high peaks around us in rich blue. More acclimatized this time, we set off with the intent to free climb as a team and forgo any jumaring. We entered a high-alpine dance up the technical slabs and cracks above, free climbing through sections we’d aided on the previous attempt. I led the first pitch out of the notch, a delicate, 50-meter M7+ through a lower slab and thin cracks to a small roof traverse up high. Vitaliy took over for the second pitch, another 50-meter M7+ consisting of delicate laybacking on poor feet and an improbable traverse to gain a section of ice.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/16.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/17.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/18.jpg]\n\nWe were now back at our high point and began the final quest upward. From our perspective in the middle of the face, the summit continued to seem distant, like a carrot dangling on a stick. Pitch after pitch, the angle remained steep and the climbing proved harder than it looked. We wove our way through another five pitches of M4–M6, swapping out leaders naturally as our individual motivations waxed and waned. The hours were catching up to us, but still, there was no rush. The sky was clear, the air gentle, and our minds certain. We were going to the top.\n\nAs we neared the summit, the blanket of blue sky shifted to reveal a horizon of golden yellows and oranges, as if the setting sun itself were wishing us well. At 7:30 p.m., under the cover of night, I climbed a final five-inch crack to a starkly flat, 50-foot swath of horizontal ridge leading to the summit. There, on a perch the size of a compact car, Vitaliy, Hayden, and I smiled, embraced, and took a moment to reflect on our journey.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/19.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/20.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/21.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/22.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/23.jpg]\n\nThe southeast face of Kishtwar Shivling in the evening alpenglow\n\nThe previous three and a half weeks of labor had finally borne fruit. We had ferried three-hundred and fifty pounds of gear to ABC and climbed through the most fatigued moments of our lives only to retreat within 100 meters of the summit. Then we’d mustered up the energy to try again, and over two days had free-climbed over 2,700 feet of technical terrain up to M7+, the most difficult pitches of which were above 19,000 feet. Had you told us that this would be the story of our climb, we all would have thought it impossible to be central characters in the narrative. From the countryside of Texas, the inner-city of San Francisco, and an adventure-centered childhood, we’d each chosen to navigate our lives with synonymous purpose. What joined us together on the summit was more than the climbing; it was a culmination of becoming who we’d wanted to be.\n\nWe were certainly proud of our climb. Moreso, however, we were proud of each other. With each new difficulty, one of us stepped in to willingly carry the burden: leading a difficult pitch, volunteering for chores, or caring for a bonking teammate. It had been the seamless flow with which we made decisions and nurtured each other's needs that made our whole stronger than the constituent pieces. The environmental stresses were only the final forging of our bonds, bonds that were ultimately strong enough to bring us to the top of the White Sapphire.\n\nSapphire, the second-hardest gem on earth (second only to diamond), is forged in a similar process. What begins as an unassuming bit of ancient seafloor is transformed into resilient gems through the deep heat and pressure of a journey below the continents. Only when the gems are finally exhumed in geologic time is their beauty evident. Much like those minerals, we’d endured our own metamorphic transformation, deep in the heart of the Indian Himalaya. In a range known for its precious gems, the newfound richness of our friendship was now exhumed, emanating like the light through a Kashmiri sapphire: Brilliant Blue.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/24.jpg]\n\nAtop the summit of the White Sapphire\n\nOctober 2023: First ascent of Brilliant Blue (850m, AI3, 80°, M7+), White Sapphire (6040m), Kishtwar Valley, Jammu and Kashmir region, India; Christian Black, Vitaliy Musiyenko, Hayden Wyatt.\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/25.jpg]\n\n[photo: images/journal/brilliant-blue-first-all-american-expedition-to-india-s-kish/26.jpg]",
        "related": [
          {
            "label": "See the publication",
            "url": "https://publications.americanalpineclub.org/articles/13201216837",
            "note": "American Alpine Journal"
          },
          {
            "label": "Listen to the story",
            "url": "https://open.spotify.com/episode/41l2FZsr6P5TJMw7TJtEG1",
            "note": "The Cutting Edge"
          }
        ]
      },
      {
        "id": "freesnake-fix-and-follow",
        "title": "Freesnake Fix and Follow",
        "date": "2023-08-01",
        "dateLabel": "August 2023",
        "meta": "Technique",
        "lede": "",
        "cover": "images/journal/freesnake-fix-and-follow/01.jpg",
        "credits": [
          "Written by: Christian Black"
        ],
        "pullquote": "",
        "body": "Hayden Wyatt freesnaking while following the crux pitch of Riders on the Storm , Cirque of the Unclimbables, Canada\n\nFix and Follow (aka \"Freesnaking\") has grown in popularity among multipitch climbers over the last few years. To my knowledge, Josh Wharton was the earliest adopter of the Fix and Follow for long free climbing routes and other high end professionals like Mikey Schaefer almost exclusively use this system on long free climbing routes. My climbing partners and I have adopted this system and have used it extensively over the last 4 years, adding some tweaks for different scenarios and have had great success. There are many different flavors to this system, but the gist is always the same: The leader fixes the rope and the follower self-belays on a top-rope solo setup. Aside from easy rope management, it also helps the leader save energy by not belaying and allows them time to eat, drink, take photos or haul a day pack if needed. That being said, this is an advanced system and is best only for the very experienced multipitch climbing parties in certain scenarios. Below I'll outline our most recent form of the system. For other references, see Josh Wharton's article and Mikey Schaefer's Nugget Podcast talking about fix and follow .\n\n## The Basic Setup: Leader\n\nFor the Leader, the system is pretty simple. The leader is belayed like normal, and upon reaching the anchor simply fixes the rope to the anchor without pulling up any slack. My preferred method is to clove-hitch to the anchor like normal, take a couple of feet of slack behind the clove and fix the rope again to a second knot, usually an alpine butterfly because it's the easiest to untie when weighted or jugged on. The second knot adds a level of redundancy and also allows slack for the leader to adjust their clove hitch length later on if needed. At this point, the leader yells \"off belay, rope is fixed!\" and can relax, eat or drink, take photos, etc. This is also a great opportunity for the leader to haul a daypack if the climbing is hard enough to warrant not climbing with the pack.\n\n## Leader: Daypack Hauling\n\nWhile the follower is top-rope soloing, the leader can haul a daypack on a thin tagline. My go-to is the Petzl Pur-line because of its weight and durability. The setup is simple; the leader uses a small progress capture like a Petzl Nanotraxion to haul the bag up. Having a foot-haul method can be helpful to save energy in your arms for the climbing. For foot-hauling, a second progress capture is clipped to the haul side of the tagline with a sling as a foot loop, allowing the leader to push their leg downward on the slack side of the haul line to bring the bag up. Alternatively, there is typically enough friction to achieve the same effect by just wrapping the tagline around your foot and pushing down. It is slightly less ergonomic, but also saves you from having to carry a second device and the setup is simpler. Play around with which system you prefer!\n\nTaglines are notoriously annoying to manage at the belay because they are so thin, so it's good to have a strategy to make sure it doesn't add any cluster or inefficiency to your system. I've experimented with two main ways to manage the tagline.\n\nCoil-as-you-haul method : With the haul device clipped high on the anchor, I use an extended alpine draw clipped to itself below on the anchor to coil the tagline onto it as I haul, stopping every so often while hauling to stack the tagline nicely. I like to start with small coils and slowly make them longer until the bag reaches the anchor. Once I dock the bag, I simply roll the tagline in the sling so the short coils are on top and the tagline is ready to feed out nicely for the next leader. This is the exact same way I haul bags while bigwall climbing, and it's probably my preferred system. Slightly more organizing work for the leader but more efficient overall.\n\nFreesnake the tagline method : An alternative method is to simply haul the bag and let the free end of the tagline dangle lower and lower without a knot in the end until the bag reaches the anchor. At that point, the haul line should be freesnaking in a single strand below the anchor. The follower needs to use one of their microtraxions to hold the tagline weight and feed the leader tagline as they climb the next pitch. This system is less work for the leader and more for the follower. It is best used on clean faces where tangly taglines can't loop around themselves and create knots (low-angle ledge systems etc.) The caveat is that the follower will have to manage the tagline slack and lead rope slack while belaying the leader if combining with a fix and follow system.\n\n## The Basic Setup: Follower\n\nOnce the leader is off belay and the rope is fixed, the follower simply has to install their top-rope solo system and start climbing. The end of the climbing rope hangs below them without a knot in the end which typically provides enough weight below so that the devices feed effortlessly off the belay. The standard method is to use two progress capture devices to provide a level of redundancy. I personally prefer two microtraxions for rock climbing, as they slide up the rope the easiest. However, with icy or snowy ropes Josh Wharton suggests a Camp Lift is better as one of the devices.\n\nFor the top-rope solo setup, I have made some tweaks that I think improve the efficiency and ease of use. The setup is fairly simple; the lower device is clipped to the belay loop with a locker (autolocker is nice), while the upper device sits extended above the belay loop on a secondary masterpoint. I like to use a 120cm dyneema sling girth-hitched through the harness hard points (keep the bar tack as close as possible to the girth hitch), and tie an alpine butterfly in the sling just above the belay loop. The upper device is clipped to the alpine butterfly masterpoint and a neck bungee is clipped to it to orient the device upright and separate it from the lower device. The tail of the sling is also available to use as a built-in personal tether for anchoring in. I prefer to girth-hitch a small locker to the end to keep the system tidy.\n\n[photo: images/journal/freesnake-fix-and-follow/02.jpg]\n\n120cm sling with alpine butterfly extended masterpoint and built-in personal tether\n\n[photo: images/journal/freesnake-fix-and-follow/03.jpg]\n\nNeck bungee that stays around neck at all times and is easy to clip and unclip from the system\n\n[photo: images/journal/freesnake-fix-and-follow/04.jpg]\n\nBuilt-in personal tether for anchoring at the belay\n\n[photo: images/journal/freesnake-fix-and-follow/05.jpg]\n\nThe personal tether can be easily shortened for comfort by using a quickdraw from the alpine butterfly to the anchor\n\nAs shown from the photos above, the 120cm sling serves many purposes. Additional benefits include:\n\nEasy transition to rappelling : I f working a section of a route and you need to rappel down, simply take up slack on the upper microtraxion only, leaving the belay loop device free to swap out with a grigri. Then take up on the grigri and the upper device will be slack and easy to remove. Rappel as needed.\n\nDoubles as a rappel extension : A secondary added benefit is that this is the exact same rappel extension setup I use when multipitch rappelling, covered in depth here (article coming soon). Simply put your ATC on the alpine butterfly, third-hand backup on the belay loop, and you are ready to rappel with your rappel extension and personal tether built into one system.\n\n[photo: images/journal/freesnake-fix-and-follow/06.jpg]\n\nKeenan top-rope soloing during a fix-and-follow ascent of Lotus Flower Tower in a day, while I eat snacks and take photos\n\n[photo: images/journal/freesnake-fix-and-follow/07.jpg]\n\n## At the Belay\n\nOnce the follower is at the belay, they will first tether into the anchor with their built-in personal anchor and then take off their microtraxions. With one of the microtraxions they will re-install it on the rope hanging below such that it now holds the rope weight and clip the micro high on the anchor. The follower can then pull a loop of slack through the device and put the leader on belay. The belayer continues to pull slack as needed through the microtraxion to feed to the leader as they belay. If needed they can do the same with the tagline if it is also freesnaking.\n\nYou can see this system in action on the photo on the left. The microtraxion on top is holding the weight of the entire lead line below. A loop of slack comes out of the microtraxion into the belayers grigri. The lead rope is incrementally pulled up as the belayer gives out slack. Once the leader is off belay, the belayer can leave the rest of the rope hanging, install their top-rope solo setup and start climbing. It's a beautiful thing climbing thousands of feet and not coiling a single inch of rope!\n\n## Caveats: When NOT to use this system\n\nThere are plenty of scenarios where this system is not appropriate. Below are considerations I take into account when deciding whether fix and follow is the best choice:\n\nNew climbers - this system requires a robust understanding of the gear used and all potential drawbacks. Learn to be a proficient multipitch climber with standard systems before experimenting with advanced systems.\n\nOther parties on route below - it is generally annoying to lead a pitch having a rope dangling in front of your face. Be considerate of other parties and don't use fix and follow if the rope hanging below will be in their way.\n\nTraversing pitches - Fix and follow is not the best choice for pitches or climbs that traverse a lot or require a down-climb, as the rope weight below will tug on the follower and can make the climbing more difficult. In this case it's best to switch to a normal top-belay for those pitches.\n\nStrong wind - With the rope freesnaking below, strong wind can throw the rope around a corner or get stuck in flakes/features off-route. It could require a rappel or a cut rope to fix. In this case, it's best to use a normal top-belay.\n\nPotential for loose rock to be pulled off - If there is any significant likel i hood of the follower pulling off loose rock, you do not want your climbing rope below to be exposed to rock falling on it and damaging or cutting the rope. Use a traditional top-belay for pitches where very loose rock is encountered.\n\nLong rope-stretch pitches - Because the belayer is not tied into the rope, they must be VERY aware of the end of the rope. If the end of the rope gets within 15 meters of the anchor I will pull it up and tie it to the anchor or tie-in to close the system and avoid the possibility of the end of the rope passing through the the grigri and causing cat a strophic system failure.\n\nSwinging Leads - Fix and follow is best used block-leading to minimize transitions from leading to top-rope soloing. Block leading is typically a more efficient system for long or difficult routes anyways.\n\n## Variations\n\nOver the years I have developed a few variations to this system for certain scenarios, some covered in separate articles below.\n\nBigwall Freesnake - a system that uses a freesnaking lead and haul line to improve rope management and efficiency on bigwall terrain (article in the works)\n\nShort-fix and follow - short-fixing on big walls, the leader simply pulls up slack to self-belay before fixing the rope. Typically used with aid climbing but could be combined with free climbing.\n\nParty of 3 fix and follow - two followers can top-rope solo on a single rope, separating themselves by about 10 meters, provided the route is fairly straight with minimal traversing. Ensure there are adequate directional pieces for all followers. Best used on moderate terrain where follower falls are unlikely. A two-rope system could also be used with each follower on their own rope.\n\nParty of 3 short-fix and follow - the same system as above, except the leader pulls up all slack rope except that needed for the followers to climb before fixing the rope. The first follower to reach the anchor then puts the leader on belay and has ample slack to belay the leader while the second follower is still climbing to reach the anchor. Great for moderate climbs as a party of 3 on a single rope. The leader may need to hang out if they run out of slack while waiting for the second follower to reach the anchor."
      },
      {
        "id": "cirque-of-the-unclimbables-2023-climb-and-packraft",
        "title": "Shandy Boy Summer: The Cirque of the Unclimbables",
        "date": "2023-07-01",
        "dateLabel": "July 2023",
        "meta": "Trip report",
        "lede": "",
        "cover": "images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/01.jpg",
        "credits": [
          "Written by Christian Black",
          "Team: Luke Groenewoud, Keenan Nowak, Hayden Wyatt, Christian Black"
        ],
        "pullquote": "",
        "body": "Shandy Boy ( Shan-dē boi, noun ): a characteristically non-masculine male that exhibits qualities traditionally associated with females, such as being in touch with your emotions, having a sense of style, or drinking light shandy beers.\n\nJuly had arrived in the U.S. , meaning only one thing – it was time for the yearly escape north to the temperate climate of Canada. Another spring season of field-biology work had come and gone and I was ready to trade the dry sands of the Mojave Desert for the cool, humid air of the north. On the docket for this summer was a remote dreamland that had remained in our imagination for years – the Cirque of the Unclimbables. Discovered by Alex Wextler in 1955, the Cirque of the Unclimbables lies deep in the wilderness of Nahanni National Park in Canada’s Northwest Territories. The granite basin hosts innumerable spires, the most famous of which is the Lotus Flower Tower. Getting to the Cirque is a big logistical challenge in and of itself, requiring a lengthy drive from Squamish and a float plane shuttle to access the trailhead. In typical fashion, we decided it would be fun to complicate things even more and planned to packraft the South Nahanni river eight days back to civilization. Not that any of us had ever packrafted before. Learn by doing, right? Right…? Our team consisted of Luke Groenewoud, Keenan Nowak, Hayden Wyatt and myself. It was a dream team that would surely make even the shittiest of experiences some of our best memories.\n\nLogistics and Nahanni National Park Permit information HERE\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/02.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/03.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/04.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/05.jpg]\n\nTwo days of stress-packing soon had us on the twenty-five hour drive north from Squamish, British Columbia to our final destination of Finlayson Lake, Yukon, where we met with the owner and pilot for Inconnu Lodge and Kluane Airways, Warren LaFave. Although his main business is a backcountry fishing and hunting lodge, Warren holds legendary status amongst the travellers of the Cirque as the main pilot flying climbers into the Cirque for over 30 years, including legendary climbers like Paul Pianna, Todd Skinner and Tommy Caldwell. During our hour-long flight, he told countless stories about the history of the cirque, including a cleanup of the cirque he helped organize with climbers before it was integrated into Nahanni National Park in 2009. This was all told, of course, with the colorful and sometimes outdated language of the seasoned Yukon pilot.\n\nUpon landing the float plane at Glacier Lake, it was clear we were indeed very far from anything. The lake was as still as glass, and only the buzzing of mosquitoes drew the attention of the ear. We unloaded our gear from the plane, including two full racks of climbing gear, taglines and ropes, packrafting gear for each of us, and 100kg of food that was supposed to support us for the next twenty-one days. Nine days of food and the packrafting gear we stashed in the bear boxes at the Parks Canada cabin at the lake before beginning the 10km hike up into the cirque. As we begrudginly lugged each of our 82lb packs up the steep approach, our spirits were held high by the towers appearing above us. The Cirque of the Unclimbables stood out as the tallest landscape feature around, concentrating an afternoon storm cloud above the peaks as we inched our way up the steep trail.\n\nAfter four hours we entered the basin and instantly understood why it was called Fairy Meadows. Granite walls in 270 degrees pierced the landscape through glacier and scree fields. Lucious heather meadows and vibrant green moss added color to the palette, and silvery glacial streams were the final brushstrokes. It truly was a landscape akin to a fairytale. We unloaded our packs and found our spot on the canvas to call home, a small but steep boulder cave that provided shelter from the ever-present rain.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/06.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/07.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/08.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/09.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/10.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/11.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/12.jpg]\n\nEven in its driest months, the Cirque of the Unclimbables is known for its frequent rainstorms, often giving climbers only a couple days of good weather within a two week window to climb. By luck of the draw, the karma gods were in our favor and the sun was set to shine for almost a full week. We opted to take a full rest day to recover from the travel, but were excited to seize the good weather the day after and set off for Lotus Flower Tower.\n\nAt 2 a.m. our alarms went off, but darkness was nowhere to be found in these high summer latitudes. The dim morning light made the landscape retain a sense of mystery as we hiked up the drainage, through meadows and over scree fields to the Lotus Flower Tower. Smoke from wildfires in British Columbia had tracked into the Northwest Territories, adding to the mystique. The air was silent except for the dribble of the glacial creek where we filled our water, and after a couple of hours we were looking up at the cracks that formed the first pitch of the route.\n\nWe split into two groups of two, Hayden and Luke, myself and Keenan. Hayden set off on the first pitch, a loose “5.8” requiring careful climbing through loose blades of rock. Quickly, however, the rock quality increased and we flowed through the lower pitches of moderate crack climbing and chimneys to the bivy ledge atop pitch 10. From here, the climbing transfers onto the truly incredible 1,000 foot headwall of the LFT. No more than a few hundred feet wide, the headwall is a seemingly endless highway of granite sticking into the sky, parallel lanes of cracks tracing the face upwards.\n\nWhat makes the headwall of the LFT unique is not just its position and exposure, but also the incredible climbing style it provides. Both feldspar and diorite knobs litter the face, offering novel face climbing akin to a mixture of the knobs in Tuolumne Meadows and Sequoia National Park. Although they look large from afar, the parallel cracks that track the face are quite shallow, only providing the occasional fingerlock and spaced but solid gear. Most of the climbing on the headwall is 5.9 to 5.10-, except for the pitch 16 crux through an often wet 5.11- roof pull. We lucked out with our weather and had the route in dry conditions, with only minor wetness on the crux roof. A fall just below the roof on mid 5.10 face climbing was the only fall of the day for me, but above the crux pitch we were all feeling the fatigue from the day building.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/13.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/14.jpg]\n\nAt this point, we were only a few pitches from the summit. Hayden hit a caloric wall from leading and belaying non-stop for the previous 14 hours, and we all took a pause to make sure we hydrated and ate our combination of chips, gummies and nut mix to bring up energy levels. I offered to lead the group up the final pitches while everyone snacked and hydrated, a hero hand crack for 150 feet followed by a strenuous and unprotected 5.8 offwidth/chimney to reach the summit. Sixteen hours after leaving the ground that morning we celebrated on the summit, still in broad daylight thanks to the high latitude.\n\nFrom the summit of the Lotus Flower Tower you receive a 360-degree view of the Ragged Range surrounding it. Parrot’s Beak next door hosts an equally prominent 2000 foot face, and down the ridge to the south the knifeblade of Mount Proboscis slices the skyline. For as much vertical rock as there is in the Cirque, it makes one wonder why it is so “unclimbable.” I think the main deterrents are the vegetated cracks of anything not south/southeast facing, and of course the fact that the middle of the Northwest Territories isn’t the easiest place on earth to get to. Regardless, the magnitude of vertical rock surrounding the LFT makes one reach into the imagination and wonder if surely more isn’t possible.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/15.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/16.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/17.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/18.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/19.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/20.jpg]\n\nAs a thank you for safe passage, we cleaned around 20lbs of tattered cord from the 20+ years of rappel stations as we descended, replacing cord for future parties. We reached the ground six hours later at 1:30am and began the stumble back to our boulder cave. It was night again, and the smoke remained in the air as we weaved back through Fairy Meadows, hopping silty streams through fields of heather feeling as if we were in a lucid dream. Twenty-six hours after leaving the previous morning we arrived back at our boulder cave and began the much needed transition from one dream to the next.\n\n****\n\nTo rest our bodies, we lived briefly a life defined by doing exactly nothing . Somehow, we were the only people in Fairy Meadows and the weather was perfect, so off we went to explore the playground. We climbed on the many boulders strewn about, showered in the glacial streams and perused barefoot throught the soft meadows. We pretended to be marmots on top of the boulders with high-pitched yells echoing off the walls around us.\n\nRested and eager to explore another route during the good weather, Hayden and I picked out “Riders on the Storm'' on East Huey Spire, a 12d route described as ten pitches of “high quality Yosemite-esque crack climbing.” The short approach from camp and the thought of clean, splitter cracks straight up the southeast face enticed us. We opted to haul a small daybag up to the crux pitch in case we wanted to hang out and project it, but mostly it was so we could blast good tunes during the ascent.\n\nHayden climbed the first three pitches and I took four and five to get us to the base of the crux pitch. The crux pitch went smoothly, climbing a handcrack through a small rooflet into a vertical but solid fingercrack above. Hayden followed it clean so we decided to finish the climb to the top of the formation. The upper pitches eased up quite a bit, although there was the usual alpine looseness to navigate to the summit. In general, we found the pitches on the route were quite short and felt relatively easy for the suggested grades, a nice surprise after the Lotus Flower Tower. From the summit we could see the entirety of the massive walls of Mt. Sir Harrison Smith at the southern edge of the cirque. Atop East Huey Spire we were at the center at the granite fish bowl that comprised the cirque.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/21.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/22.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/23.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/24.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/25.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/26.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/27.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/28.jpg]\n\nFairy Meadows hosts a number of short climbs and boulders to be explored. Some of our favorites were the 11d roofcrack near the latrine, “The Penguin'', a 12a bolted climb (or a 12+ extension if you start from the ground rather than the upper tier), and some single pitch crack climbs at the base of East Huey Spire. These make for great climbs to explore for half days of good weather when afternoon thunderstorms thwart any possibility of doing long routes .\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/29.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/30.jpg]\n\nAnother rest day of eating homemade dehydrated meals, quesadillas, fried burritos and playing copious amounts of Monopoly Deal had us left with one final day of good weather. In this range, six days of clear weather without rain was almost unheard of so we rallied our sore bodies for one last outing. Hayden and I picked out Mt. Sir James Macbrien peak, a peak that marks the northernmost end of the cirque and is the second highest point in the Northwest Territories. Our plan was to climb the 5.9+ Southeast Arete and continue traversing west along the ridgeline to scout the possibility of a traverse linkup in the future.\n\nAfter a two and a half hour approach up talus from camp, we arrived at the base. Even for one of the most unimpressive peaks in the cirque, Sir James Macbrien still stood proud, reminding me of an ancient castle made of granite. Hayden set off on a simul-climbing block for the first half of the route and I took over for the second. While the lower pitches offered fun and clean 5.9 climbing, we found the upper three pitches to be loosely stacked blocks in a wide chimney, frequently playing the choss-drums in a spicy elimination game of “don’t touch this one.”\n\nOnce past the 3rd and 4th class scrambling to the summit, the views open 360 degrees to reveal the hidden valleys to the north and all of the summits in the cirque to the southwest. If you are very comfortable climbing loose rock, I would recommend Mt. Sir James Macbrien just for the summit views alone.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/31.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/32.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/33.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/34.jpg]\n\nWe traversed west from the summit along the ridgline, which also happened to be the descent route, deciding we were in fact far too pooped to imagine trying any more climbing for the day. Eventually we came to the main notch between Parrot Beak Peak and Mt. Sir James Macbrien and spotted a mountain goat high on the knife edge ridge, following the 3rd and 4th class goat trail down into the valley and back to camp.\n\nOur final days in the Cirque were welcomed with an onset of daily rain and an influx of new climbers arriving. Although shy at first, they eventually warmed up to us after we pranked them by pulling 65 meters of tagline piece-by-piece out of Luke’s pants. That seemed to loosen them up enough to convince them to join us for games of cribbage and Monopoly Deal. Too soon, however, our time was up. We said bye to our new friends over a final evening of games and desserts, took a bow, and hiked down to the lake. Our climbing time was up, but we were excited to exchange our ropes for boats and follow gravity for once rather than fight it.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/35.jpg]\n\n## The South Nahanni River\n\nArriving back at Glacier Lake, a low fog welcomed us to the water. We stashed our climbing gear to be picked up and flown out by Warren, exchanging it for another 50lbs of food and our packrafting gear. A single two-person canoe was the only available shuttle boat to reach the other end of Glacier Lake and begin our hike down to the South Nahanni River, so in we piled. The silence in the air mirrored the stillness of the lake as we carefully weaved it through the fog.\n\nStruggling to shoulder our packs once on the other side, we joked that packrafting wasn’t actually that packable. We begrudgingly began a 6 hour hike through bogs and seeping muskeg, eventually reaching the South Nahanni River with sore hips, wet feet and an appetite for anything but walking. We hopped in our boats, happy to let the river do the work from there on out.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/36.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/37.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/38.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/39.jpg]\n\nThe South Nahanni River is famous in and of itself as a river trip, with guided raft parties and canoeists frequenting it each summer. There are a few variations of the trip to choose from depending on your boating experience. More experienced whitewater boaters can start on the Little Nahanni and paddle through technical class 4 rapids before portaging to the South Nahanni (this is also how you would paddle into the Cirque of the Unclimbables for the ultimate boating/climbing combo). For easier paddling you can put in at the headwaters of the Nahanni on the Broken Bow and run the river from its incipient shallow flows, with a layover to to hike up to Glacier Lake and the Cirque along the way. Our section from the Cirque of the Unclimbables (Britnell Creek) to Nahanni Butte would take us 220 miles (353km) from the slow rolling mountain river, through four canyons with rapids, and finally to the meandering braided river as it exited the mountains and entered the plains. This would be our highway back to civilization over the next eight days.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/40.jpg]\n\nOur first evening on the river landed us sharing campsites with a generous group of Canadian canoeists, sharing stories around a fire and reminiscing on the joy of centering life around wild experiences. They too had led unconventional lives, foregoing money for time and enoying the freedoms it provided. It was reassuring to hear from an older generation that they had no regrets in their path, the evidence of which was present in the constant smiles on their faces.\n\nFor the next two days we laughed and basked in the relaxation that gravity provided us in our effortless descent down the Nahanni. Lounging in the boats, listening to music and eating food all day seemed far too easy. Lucky for us, the river kept us humble as it screeched to a halt on our third day, requiring us to paddle for 13 hours through 47 miles of flat water to reach our scheduled camp. With aching shoulders that day we reached Virginia Falls. A quick portage the following day put us at the start of the rapids where we would get to test if our warm up days had properly prepared us.\n\nEven though we had little to no packrafting experience, the Nahanni River proved to be a gracious teacher. The intro rapids in Fourth Canyon proved to be straightforward sections of class 3 wave trains where we quickly learned to paddle through the peaks and lean into the troughs. After a few sections we were full of new energy, finding play in the river and paddling with ease through rapids, lounging to admire the deep cut canyons in between.\n\nMy geology background came in handy during our days paddling the canyons. The massive walls of the canyons were a marine delta sedimentary deposit, with each canyon slowly transitioning from from mud-dominated marine delta sediments to sand-dominated marine delta sediments as we paddled downstream and down-strata, the results of which were that each canyon’s walls were strikingly more erect than the next. By this point paddling had become second-nature and our ten hour days on the river had me convinced I had been doing this my whole life. That was, at least, until I flipped my boat for the first time on the last rapid of the river and lost the water filter.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/41.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/42.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/43.jpg]\n\nAs the canyons came and went, the Nahanni, too, changed form. The swift currents and rapids of the steep walled canyons now released into the low angle plains, forming a relaxed braided river. It was as if the water finally had time to stretch and release its tension and finally flow slowly onward for its final days. The calm water and open plains housed herds of bison and perched osprey curiously eyeing us as we wove through their backyard, paddling happily through the rain in our brightly-colored dry-suits.\n\nEight days and 220 miles after we left the Cirque of the Unclimbables we pulled our boats ashore for the last time into the town of Nahanni Butte. The locals welcomed us kindly, letting us shower in the community center and helping to sort our shuttle driver back to our cars in Fort Nelson. Our time as guests of the Nahanni was over. I felt inside of me a small piece of sadness, knowing that the joy created here could never be replicated in the same way. At the very least, though, it could be shared.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/44.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/45.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/46.jpg]\n\nWe have many thank you’s to give for those who helped support our trip in some way, so here they are below.\n\n-Thank you Stikine for lending us bow bags, dry bags, a dry-suit, packraft and couple of paddles for use on our trip!\n\n-Thanks to Hyperlite Mountain Gear for generously gifting us four Hyperlite Porter packs which we used extensively.\n\n-Thanks to Mustang Survival for providing discounts on dry suits for our trip.\n\n-Thanks to river guides Connor and Fraser for gifting us some extra food from the tail end of their river trip\n\n-Thanks to the Canadian Canoeists Ken, Brad, Jay and Lynne who we met on the river and generously drove our car from Finlayson Lake to Fort Nelson after they got off the river, saving us around 16 hours of driving!\n\n-Thanks John and Roxanne of Nahanni Butte for providing the shuttle from Nahanni Butte to Fort Nelson at the end of our trip.\n\n-Thank you to Vitaliy and Brian for keeping us updated with weather for our time in the Cirque!\n\n-Lastly, thanks to our girlfriends or lack thereof for letting us enjoy many weeks of backcountry boy time.\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/47.jpg]\n\n[photo: images/journal/cirque-of-the-unclimbables-2023-climb-and-packraft/48.jpg]\n\nThanks for reading!\n\n-The Shandy Boys-"
      },
      {
        "id": "mt-bute-2022-foiled-by-foliage-and-fuel",
        "title": "Mt. Bute 2022 - Foiled by Foliage (and Fuel)",
        "date": "2022-08-01",
        "dateLabel": "August 2022",
        "meta": "Trip report",
        "lede": "",
        "cover": "images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/01.jpg",
        "credits": [
          "Written by Christian Black",
          "Team: Hayden Wyatt, Christian Black and Keenan Novak",
          "Written by Christian Black, in collaboration with teammates Hayden Wyatt and Keenan Nowak. August 2022."
        ],
        "pullquote": "",
        "body": "Click HERE for full travel logistics and beta report for traveling to Mt. Bute\n\nIn February of 2022, my friend Hayden called me to catch up, the conversation ending with him asking if I would be interested in a summer rock climbing expedition to the Coast Ranges of British Columbia. Having spent three summers working and climbing with Hayden in Yosemite, I knew our similar climbing styles and banter would make for a great trip no matter what. I committed to taking the time off and asked minimal questions about what the expedition would entail. “It’s called Mt. Bute. It’s 50 pitches of rock climbing, it’ll be sweet”! I was sold. Our plan was to climb the 6000ft “School of Rock'' route on the west buttress.\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/02.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/03.jpg]\n\nAs we began planning, our friend Keenan who was joining in on the trip happened to know the first ascensionist of the route we wanted to do. Through much questioning we gathered enough information to figure out where to go and (roughly) how to get there. A slew of phone calls later and he had a 32-foot Zodiac chartered boat to take us two and a half hours to the end of the Bute Inlet from Campbell River. August came quickly and soon we were getting off the zodiac at Homathko Camp, an old homestead and logging camp where our journey would begin.\n\nFrom the start, we knew hiking into Mt. Bute would be challenging. One trip report called it a “bushwhack from hell”, so we came prepared with what we guessed was an appropriate kit of cut-resistant gardening gloves, mosquito head nets, long pants, sun hoodies, trekking poles and one machete. However, our packs were about 80lbs each, loaded with 10 days of food, camping gear, climbing gear and an additional bolt kit with 35 bolts for potential new-routing. The strawberry rhubarb pie strapped to the top of my pack didn’t help with the weight either. Nonetheless psyched, we shouldered our packs and began hiking.\n\n## The bushwhack from hell\n\nThe approach to basecamp took us two full days of bushwhacking. The first day involved two creek crossings followed by an uphill battle through new-growth logging cutblocks, dead and down forest and groves of Devil’s Club, a spiky 6ft tall plant occupying most flat areas near the creek. Day two proved to be worse thanks to side-hilling through sideways growing Maple trees and the final tromp through a wet meadow with 8ft tall berry bushes just before pulling into basecamp. We arrived utterly wrecked and covered in scratches and bug bites but the hardest part was over at leasty! Or so we thought…\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/04.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/05.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/06.jpg]\n\nThe next 3 days were drizzly weather, allowing us to rest up in basecamp where we mostly hung out by the fire to avoid the constant droves of mosquitoes and flies attacking. Two of the afternoons we spent scouting the final approach from basecamp to the base of the climb where we were humbled by the horrifyingly dense foliage guarding the path. The machete which we jokingly thought was dead weight became the MVP of the trip as we chopped an approach trail from camp through thick berry bushes, Devil’s Club, and even sawed off a section of a downed log to put across a creek to strengthen a small but consequential tree crossing necessary to cross.\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/07.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/08.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/09.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/10.jpg]\n\n> … and then Hayden’s pinky finger gets split wide open by a sharp boulder …\n\nOur second day of cutting in the approach trail and we finally made it to the base of the route to look at the climb for the first time. “This thing is huuuuuuuuuge!” we say as we stand at the base of the lower 3000ft buttress. “It’s finally time to rock climb instead of bushwhack soon!” …And then Hayden’s pinky finger gets split wide open by a sharp boulder near the base, almost tearing his nail off, finger covered in blood. We headed back to camp to clean and disinfect his finger, creating a splint concocted out of disinfectant spray glue, superglue, roll gauze and climbing tape. His finger hurt, but the splint looked good and we already made it this far, so we decided to rest up one more day and start the climb during the second day of a sunny four-day weather window.\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/11.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/12.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/13.jpg]\n\n## The Nose of Bushes\n\nThe morning of the climb our alarms went off at 2:45am and soon we weaved our way through our machete-chopped trail and made it to the base of the climb at 5am just as the sun was rising. We had tiny packs with us, hoping to climb light and make the 3000ft of climbing we were supposed to do that day easier. Between our 20L, 15L and 12L packs we had two and a half days of food, one stove, one fuel canister, short sleeping pads and one sleeping bag for all three of us to share. By 6am I was off leading the first 5.6 slab pitches to start off the route.\n\nSimul-climbing the lower 800ft of the route, we placed microtraxions to protect the followers as we wandered up terrain anywhere from 5.4 waterfalls to 5.7 friction slab. After a couple of hours we arrived at the base of the slightly steeper climbing, which was described to us using the vague phrasing “...from there, I think we climbed some bushes for a little while…”\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/14.jpg]\n\nThe lower buttress occupying the first 3000ft of the route and the bushiest climbing\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/15.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/16.jpg]\n\nThe next part of the route ended up being around 1000ft/10 pitches of dirt-filled cracks and 5.9+ bush climbing, often slinging bushes as the only protection. It felt like someone was actively fighting you while you were trying to climb, brushing branches out of your face as they snag and pull on other parts of your body at the same time. Relentless bush climbing at its finest.\n\nEventually we exited the bushy climbing and continued onwards up cryptic, often dirt-filled cracks linking ledgy terrain until we reached the easier ridge climbing topping out near the first buttress. We found a patch of snow and took a break filling water bottles from the drips and melting a few liters of water to quench our dehydration. A few hundred more feet of easy climbing and we found our bivy for the night overlooking the valley and glacier below just as sunset came. After dinner we cuddled up in the single quilt-style sleeping bag we had to share for the night.\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/17.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/18.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/19.jpg]\n\nAt breakfast the next morning, all was going well until...I heard the jetboil turn off as it ran out of fuel… our only canister of fuel. We hadn’t planned on melting any snow, expecting enough water dripping from snow patches on route. As it turned out, the ridge feature funneled none of that to us so we used up some of our fuel melting water the day before. Having no more fuel left put a big wrench in our plans, prompting a group chat after we submitted the first buttress that morning and got a first look at the upper 3000ft of the route.\n\nAhead of us lay the hardest climbing terrain and seemingly no snow or water running on the route. The answer was obvious albeit unfortunate. We couldn’t reasonably continue onto the upper 3000ft buttress with only a liter of water each for the entire second part of the route that day. We made the difficult call to bail from there and abandon any summit attempt. It was a great exercise in flexing the bail muscle and making a safe decision, but we were all a bit sad to have gotten so far only to have a miscalculation in fuel stump the whole trip.\n\n...It was a great exercise in flexing the bail muscle...\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/20.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/21.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/22.jpg]\n\nWe started our descent and began hiking down a series of grassy ledges, sometimes needing to downclimb steep dirt and duff with our ice axes to avoid slipping on the foliage. Eventually we made it to the cliff edge and rappeled a series of trees to reach the base of the route again 7hrs later that day. The climbing was over, but we were back on the ground safe instead of epic-ing while dehydrated on a remote peak.\n\nThe next morning, Keenan spearheaded the route finding on the bushwhack out and did an amazing job connecting the best parts of the old growth forest for easy walking, eventually linking into an old logging trail and an overgrown logging road that led us back to the river crossing. What took us 14 hours of bushwhacking in only took 7hrs on the way out, a huge blessing considering how worked we were by this point. Making it back to Homathko Camp that afternoon was a blissful sign that finally after 8 days the hard work was over and we could relax. No more bushes, no more scary route-finding, no more constantly swatting at bugs on your face. Maybe life wasn’t so bad this way? Soon our boat came and we were back on our way to civilization, the blur of the previous eight days forever seared into our memories.\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/23.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/24.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/25.jpg]\n\n[photo: images/journal/mt-bute-2022-foiled-by-foliage-and-fuel/26.jpg]\n\nWe are humbled and grateful for the challenges presented to us by the beautiful Coast Range mountains. Despite our thwarted attempts, we feel a small sense of joy knowing that these adventurous experiences are readily available to those who seek them out. What we will take away from this trip is the memories made with good friends in a beautiful place, working together and working hard to try to realize a dream. A very special thanks to teammates Hayden Wyatt and Keenan Nowak for making this trip so memorable; Blake Herrington, Luke Nuefeld and Jimmy Martinello for giving information, beta and photos to us before the trip; and the American Alpine Club for financial support through the Live Your Dream grant.\n\nP.S. We have created a separate Beta Report for Mt. Bute, compiling information regarding logistics, gear, GPS tracks and other things that could be very useful to future climbers. We hope this information inspires more parties to visit Mt. Bute. Link HERE"
      },
      {
        "id": "the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc",
        "title": "The P.L.U.R.L. - Penny Lane Ultimate Reality Linkup, Squamish BC",
        "date": "2022-07-01",
        "dateLabel": "July 2022",
        "meta": "Trip report",
        "lede": "",
        "cover": "images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/01.jpg",
        "credits": [
          "Written by Christian Black",
          "Team: Hayden Wyatt and Christian Black"
        ],
        "pullquote": "",
        "body": "Everyone knows Penny Lane, 5.9, is the best climb in Squamish. The only problem is, don't you just wish it was longer? Don't you wish it went on for many more pitches, and you could climb it for hours on end?\n\nWell, in an effort to address our unsatiated Penny Lane fervor, Hayden Wyatt and I teamed up to create a linkup that we thought recreated the best parts of Penny Lane so we could have a never-ending Penny Lane experience.\n\nWe present to you, the Penny Lane Ultimate Reality Linkup (The PLURL) .\n\nWe chose to start at midnight to help recreate the experience of the early start necessary to beat the crowds to Penny Lane on a Saturday morning\n\nI awoke at 11:15pm after a solid 45 minutes of sleep. I had hoped for at least 3 hours but the excitement and nervousness of the next day kept me restless. A quick breakfast and I was on my way to pick up Hayden so we could try to start climbing our first route at midnight.\n\nHayden and I had been hanging out in Squamish for the summer trying to prepare for a trip into the bush to attempt Mt. Bute , so he came up with a whacky linkup idea to whip us into big route shape; climb every major formation in Squamish in a one day. This included Shannon Falls, The Papoose, 1st Chief, 2nd Chief, 3rd Chief, The Malimute, and Slhanay. Jokingly we thought it would be good to add Squamish's most famous route to cap it off, Penny Lane. Our plan was to start at midnight and simul-climb each formation as fast as we could until we finished. By our guidebook estimation it would be around 55 pitches, all 5.10c or easier. To add to the excitement, this was my first trip to Squamish so every route we had planned would be new to me!\n\nWe had with us a double rack to #2 camalots, around 16-18 slings/draws, 4 microtraxions and a 60-meter rope. In addition, we each carried a Black Diamond 8L trail running pack to store our approach shoes, water and snacks. Concerning tactis, we opted to employ our tried-and-trued freesnake simul-climbing technique . This is a method Hayden and I developed through the years that we think combines the best elements of safety and efficiency. In short, we place microtraxions every ~rope-length to protect the leader in case the follower falls and only utilize 40 meters of rope between us to minimize rope drag. The follower is attached to the rope via a grigri on their harness and a ~1m loop of slack below the grigri attached to a locker on the belay loop to provide a cache of rope to adjust position and a secure backup. The remaining 20 meters of rope drags below the second without a knot in the end which is a much more pleasant and easily-adjustable way to climb than using kiwi coils or similar methods.\n\nThe first splitter hands pitch of Sp irit of Squamish fondly reminded us of the top hand jam section of Penny Lane\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/02.jpg]\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/03.jpg]\n\nAt 12:08am we were tied in and I was off leading the first pitches of Spirit of Squamish , an 8 pitch 5.8 up the left side of Shannon Falls. Twenty-six minutes and two pitches later we were at the top and were quickly jogging down the trail on our way to The Papoope next door.\n\nThe 5.6R slab pitch of Hairpin was eerily reminiscent of the slab runout to the anchor on Penny Lane\n\nBy 12:59pm we were starting up The Papoose, where I quickly realized it was on the wrong route and had to rap off of a bolt on lead 20ft off of the ground. After some in-the-dark searching for the correct route, we were at the top of the 5-pitch Hairpin 5.10a route, climbing it in one long pitch over 31 minutes.\n\nWe really had to trust our feet on the 5.8 laybacking of Diedre, just like trusting the slick feet on Penny Lane\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/04.jpg]\n\nTopping out the 1st Chief\n\nAt 2:25am we were poised to start climbing 1st Chief, opting for a linkup of Diedre into Butt Light for 13 pitches of 5.9 fun. Hayden led the whole thing in two pitches and by this point we were in a pretty good flow despite sweating through the humid night temperatures. At 3:52am we stood atop the 1st Chief, quickly tagged the true summit and began the descent trail on our way to the Malimute.\n\nThe steep fingers and hands section of Quagmire Crack were quite challenging, just like that middle crux on Penny Lane with the bad finger lock\n\nCrossing the footbridge to the top of the Malimute around 4:30am, the sun began to rise and we started to feel first bonk . We wasted a bit of time trying to rappel into the Malimute rather than just hike to the base, but at 6:09am we stood atop the formation once again, having climbed Canadian Compromise into Quagmire 5.10c. The 3 pitches of 5.10 climbing had us warmed back up and we were starting to feel a second wind of energy thanks to the rising morning sun.\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/05.jpg]\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/06.jpg]\n\nWe noticed there weren't any fixed anchors at op the pitches of Angels Crest , so we were glad to have practiced building natural anchors so many times at the top of Penny Lane.\n\nAfter a quick drive up the FSR road to the parking for Angels Crest 5.10b, we briefly refueled with some food and energy drinks at the car before hiking up to start the mega-classic climb up the 2nd Chief. Starting at 6:50am, Hayden led the first half of the route in one pitch while I took over the second half for the second pitch. One hour and 56 minutes later we stood atop the 2nd Chief where were met with our friends bringing us a resupply of water, food, and some #3 and #4 camalots for the rest of the day. Again we quickly tagged the true summit and ventured over to what would become the most horrendous part of the day: down-scrambling the incredibly loose and sketch North North Gully.\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/07.jpg]\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/08.jpg]\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/09.jpg]\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/10.jpg]\n\nTh e adventurous choss of the North North Gully had us carefully watching our footing, similar to when you walk at the top of Penny Lane and try not to shower rocks on people below\n\nEntering the gully, it quickly became apparent that extra caution would be required on the descent. The entire gully is made up of deteriorated granite, loose blocks and even a couple of cliff drop-offs that required rappelling. The second of these rappels resulted in my favorite part of the outing which was watching Hayden disappear through a vertical hole in tree foliage.\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/11.jpg]\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/12.jpg]\n\nWe found the North North Arete route to be quite ledgy and alpine feeling , with the abundance of loose sand on the ledges recreat ing perfectly the sandy ledge atop Penny Lane.\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/13.jpg]\n\nEating some anti-bonk sausages atop North North Arete\n\nEventually we made it to the base of the North North Arete 5.9+ on the 3rd Chief around 11:10am unscathed from the harrowing descent. Halfway through the route our tiring minds reached second bonk and we wasted a decent chunk of time route-finding the final section of the route before topping out at 1:00pm.\n\nAfter a long journey bonking up the third Chief, we headed down the trail to Slhanay to climb Birds of Prey, where we thought the first pitch slab finger crack felt just as locker as the fingerlocks on Penny Lane\n\nThe early afternoon sun was beating down on us as we hiked the descent trail from the top of the 3rd Chief to the base of Slhanay. Arriving to the base just after 2:00pm, we continued to bonk our way up Birds of Prey 5.10b in just over an hour with two simul-climbing pitches.\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/14.jpg]\n\nThe final pitch of Birds of Prey\n\nTo culminate our journey, we very slowly made our way over to the Smoke Bluffs to climb no other than Penny Lane itself. After the previous 54 pitches of Penny Lane-esque climbing, we felt well prepared for the challenge ahea d\n\nFrom the top of Slhanay, we made no quick time meandering to the cars and driving to the Smoke Bluffs parking lot. Around 4:45pm we finally roped up and climbed the ultra-classic Penny Lane 5.9, using all of our previous skills from the day to ensure our success.\n\n[photo: images/journal/the-p-l-u-r-l-penny-lane-ultimate-reality-linkup-squamish-bc/15.jpg]\n\nAt 5pm, standing atop Penny Lane, we looked behind us to see all of the glorious formations we had climbed that day. Tired and bonking, we finally felt satiated and, for once in our lives, we didn't wish to climb Penny Lane anymore\n\nIf any of you, like us, are Penny Lane lovers, we humbly invite you to experience the grandeur of the Penny Lane Ultimate Reality Linkup for yourselves. Below are our route stats, we know they can be beaten so we hope so me folks get after it!\n\nStart time: 12:08am (at the base of Shannon Falls)\n\nShannon Falls - Spirit of Squamish 5.8, 8 pitches - 26 minutes\n\nThe Papoose - Hairpin 5.10a, 5 pitches - 31 minutes\n\nFirst Chief - Diedre to Butt Light 5.9, 13 pitches - 1h14m\n\nThe Malimute - Canadian Compromise to Quagmire 5.10c, 3 pitches - 41 minutes\n\nSecond Chief - Angel's Crest 5.10b, 13 pitches - 1h56m\n\nThird Chief - North North Arete 5.9+, 7 pitches - 1h42m\n\nSlhanay - Birds of Prey 5.10b, 5 pitches - 1h10m\n\nSmoke Bluffs - Penny Lane 5.9, 1 pitch - 12 minutes\n\nEnd time: 5:00pm (top of Penny Lane )\n\nTotal time start to finish: 16h52min"
      },
      {
        "id": "patagonia-pt-1-success",
        "title": "Patagonia Pt. 1: Success",
        "date": "2020-02-01",
        "dateLabel": "February 2020",
        "meta": "Trip report",
        "lede": "",
        "cover": "images/journal/patagonia-pt-1-success/01.jpg",
        "credits": [
          "Written by: Christian Black"
        ],
        "pullquote": "",
        "body": "My goal in recounting this experience and this trip is to normalize telling a holistic experience of what can happen in the mountains. I don’t see much use in recounting heroic tales of success without also the lessons of failures and mistakes. I hope you can learn from mine.\n\nIt was January of 2020 and my first trip to Patagonia to climb in the Fitz Massif. My friend Otto, his friend James, and my cousin Chase joined me. To be frank, these mountains wildly intimidated me, and I went into the trip with very low expectations. Getting out alive, well and learning as much as possible were my only real goals. We learned the lay of the land in Chalten, found a good housing option for two months and settled into the daily routine of breakfast, weather forecasting and afternoon bouldering.\n\n[photo: images/journal/patagonia-pt-1-success/02.jpg]\n\nA week after we arrived, a 24hr weather window materialized and we trekked into Piedra Negra to lay our eyes on the mountains for the first time. We had committed to upholding conservative decision-making as we made our way up the Guillo couloir, turning around just as we topped out the couloir and intercepted the ridge. We rappelled down and navigated the glaciated terrain back to our campsite before dark. Down safely, we counted that as a success.\n\n[photo: images/journal/patagonia-pt-1-success/03.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/04.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/05.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/06.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/07.jpg]\n\n## Aguja De l’S\n\nFast forward two weeks and we found ourselves at the top of our first Patagonian summit, having climbed a variation of the Austriaca route on Aguja De’l’s. We trekked into Laguna Sucia, bivvying at the boulder cave with a group of friends from town, climbing the route and descending all the way back to town the following day. We had some of our first experiences rock climbing in post-snow-storm mixed conditions, but we eventually got into a groove and figured out how to blend our styles to match the conditions. Another trip back to town safely, another success.\n\n[photo: images/journal/patagonia-pt-1-success/08.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/09.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/10.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/11.jpg]\n\n## Fitz Roy\n\nAs February approached, word of a massive 6-day weather window sprawled through town. Not keeping our hopes up, we continued to check the forecast and were surprised that it was actually set to materialize. As this was likely our only opportunity for a big route, we settled on climbing the Afannassief , a 5000ft route up the Northwest Ridge of Fitz Roy. We knew the route was well within our technical abilities but kept expectations low knowing that the conditions on route could be poor. On February 4th, with a perfect weather forecast, we hiked over Paso Guillaumet onto the Fitz glacier below the Northwest ridge.\n\nThe next morning we hiked the snow ramp to the base of the route and waited for the sun to crest before starting. Chase and I carried 20L and 30L packs with 4 days of food, a single sleeping bag and a light tarp to share. Otto and James trailed behind us as a second rope team. A few verglassed 5.10 pitches down low gave way to easier scrambling above, leaving us at our first bivy just below the central slabs. We enjoyed a leisurely evening and chatted briefly with a Swiss team also bivvyng there.\n\n[photo: images/journal/patagonia-pt-1-success/12.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/13.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/14.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/15.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/16.jpg]\n\nThe following day it was apparent the previous storm had deposited much more precipitation on route than we had hoped. Snow and ice filled the cracks of the central slabs, causing us to wait until noon before climbing. As we danced our way up the cracks a light cloud surrounded us, offering only brief views to remind us of our position. The day remained calm and tranquil, but thousands of feet of climbing later and there was still no bivy in sight. The sun dipped behind the western ice cap and the lingering cloud finally obscured our visibility, our headlamps unable to penetrate more than 30 meters. I did my best trying to climb the most logical terrain but was suspicious we may have gone off route.\n\nClimb rambling rock, kick steps in the snow with my climbing shoes, use my ice axe to pull through an ice bulge, stem around the ice on the dry rock.\n\nI was at least getting used to the shenanigans style of mixed climbing conditions the mountain required.\n\nAt 1:30am we reached a ledge big enough to sleep all four of us. The cloud had begun to snow gently on us as we rigged up our single tarp for shelter, all four of us huddled underneath. I used my buff to cover my eyes as a sleep mask in an attempt to block my view and forget where I was for the night.\n\nThe following morning we awoke to another sunny and windless day with fresh snow blanketing the upper mountain. Almost certainly off-route, we aid climbed 4 pitches of steep cracks in front of us before intercepting the ridge and regaining the route. The mixed conditions kept us on our toes. One pitch in particular I remember starting off free-climbing a snowy crack in approach shoes and gloves, quickly switching to aid climbing by clipping to my ice axe in a crack as a makeshift fifi hook, then putting in some cams to aid-climb around the corner before chalking up and free-climbing to an anchor. I was beginning to enjoy the bullshit style mixed climbing as both engaging and entertaining at least.\n\n[photo: images/journal/patagonia-pt-1-success/17.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/18.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/19.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/20.jpg]\n\nBack on route, we had no idea where we were on the mountain, but after consulting an aerial photo determined we were only 150 meters below the summit. It was 4pm and the day was calm as we climbed the final rambling mixed pitches to the summit, stemming around icy sections and using our single axe to pull through without having to don crampons. The normally dry summit of Fitz Roy was covered in low angle soft rime-ice snow as we hiked to the top. The clouds lifted briefly and gave us a view to the town of El Chalten 10,000ft below and the peaks of the Torre Massif to the west. We took a celebratory crab-pose photo before beginning our descent, possibly the one I am most proud of in my collection.\n\n[photo: images/journal/patagonia-pt-1-success/21.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/22.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/23.jpg]\n\nAfter a few rappels, we found our bivy spot for the night, a tiny 5ft x 5ft flat ledge to share between the 4 of us. We agreed it was mandatory to group-spoon, no one was allowed to sleep on their back and take up too much space. If one person turned, we all turned. Although the most scenic spot I’ve slept in, the small ledge yielded the worst night of sleep in memory. The sunset views almost made up for the tearing shoulder pain of side-sleeping on ice, but not quite.\n\nThe following morning was ice cold. As per usual at this point, my approach shoes were frozen solid and required thawing in my sleeping bag before continuing our descent. Most people opt to rappel Fitz Roy via the Franco Argentina route on the southeast side to La Brecha and Paso Superior. However, none of us had been to that side of the mountain and we were doubtful of onsighting the descent. Instead we chose to rappel the 4500ft west face of Fitz Roy via the Francesca Cara Norte, an effort that would take 12 hours of rappelling and 31 double-rope rappels to reach the ground. We later found out almost no one descends this way. Hmmmm. Wonder why.\n\n[photo: images/journal/patagonia-pt-1-success/24.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/25.jpg]\n\n[photo: images/journal/patagonia-pt-1-success/26.jpg]\n\nShortly before reaching the ground we watched the late afternoon sun cause a small rockfall high on the snow slope. The rockfall started a small sluff in the snow that turned into an ever-widening wet slab avalanche. The mass of running snow slammed into a series of car and house-sized boulders atop granite slabs, pushing them over a cliff in an immense display of power. Humbled by the power of our surroundings we hurried down the snow slopes and back to our glacier camp as fast as we could to mitigate hazard. (In retrospect, it would have been safer to wait until late into the night or early morning to descend in the most favorable snow and temperature conditions). That same evening, we hiked over Paso Guillamet to Piedra Negra. The Fitz Roy glacier had receded almost a quarter mile since we were on it last. What was once easy walking was now a sloshy glacial moraine that filled my shoes with gravel as we stumbled into camp.\n\nThe next morning we continued our hike back to town, taking a pit stop at Piedra del Fraile Refugio on the way. Otto and James had proudly maintained voluntary constipation the previous 5 days despite their horrifying on-route diet: pre-made cream cheese and jam sandwiches, a bag of cookies and ever-rotting pre-cooked ground beef with a nightly swig of olive oil for added calories. We later got them to admit this wasn’t the best culinary decision they’ve ever made. Gut health aside, we had made it down safely from Cerro Chalten , thankful she had graced us with safe passage.\n\n[photo: images/journal/patagonia-pt-1-success/27.jpg]\n\nDuring the asadas and festivities following the good weather we heard everyones stories from the previous week. There were many ascents of Cerro Torre, new routes freed and many parties who bailed or changed plans due to the snowy conditions. As we learned later on, we were one of only two parties to summit Fitz Roy that weather window, the other being the Swiss team we encountered on the Afannassief. According to a friend, other folks in town referred to us as the “crazy Americans'' who managed to summit Fitz Roy in poor, snow-covered conditions sans crampons. I think the reality is we didn’t know any better at the time. If an experienced Chalten climber had tipped us off that the route would likely be in unideal shape for rock climbing, we probably would have bailed and chosen a different option. Since we didn’t know any better, we just kept climbing and figuring it out and somehow it kept on working. Was it disaster style? Or were we just actually fit to climb the route despite conditions? I’m not totally sure of the answer honestly, maybe it’s a bit of both.\n\nContinue reading Patagonia Part 2: A Near Tragedy\n\n[photo: images/journal/patagonia-pt-1-success/28.jpg]"
      },
      {
        "id": "patagonia-pt-2-a-near-tragedy",
        "title": "Patagonia Pt. 2: A Near Tragedy",
        "date": "2020-02-01",
        "dateLabel": "February 2020",
        "meta": "Trip report",
        "lede": "",
        "cover": "images/journal/patagonia-pt-2-a-near-tragedy/01.jpg",
        "credits": [
          "Written by: Christian Black"
        ],
        "pullquote": "",
        "body": "With the success of De’l’S and Fitz Roy behind us, I was pretty content with our trip. It was early February and we were enjoying a couple weeks in town recovering, bouldering and eating plenty of empanadas. We had gained a better understanding of the climbing conditions and felt for the first time that we knew what we were doing, at least a little bit. So, when a three-day weather window materialized in late February we were excited to attempt the Motocross Traverse which connects the summits of Aguja Guillamet and Aguja Mermoz via a technical ridge.\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/02.jpg]\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/03.jpg]\n\nOur plan this time was to try the traverse in a long day, foregoing bivy gear and preparing for the possibility of a 24+ hour outing. The weather was forecasted to be sunny, windless and warm. We awoke at midnight to begin the approach to the Amy Couloir on Guillamet, finding temperatures in the couloir oddly warm despite it being 3am. By 5:45am we were on the summit of Guillamet and began traversing the gendarmed South Ridge of Guillamet. We found this section much longer and trickier than expected, but by 11:30am we had navigated the complexities and were at the final rappel into the col between Guillamet and Mermoz.\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/04.jpg]\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/05.jpg]\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/06.jpg]\n\nThis is where things get a little complicated, so I will do my best to explain the situation:\n\nWe were climbing in two parties of two; Chase and I on one rope team and Otto and James on another. Otto and James rappelled into the col first, noticing that the large slung block anchor below had almost entirely melted out of the ice. The boulder was loose and they had no choice but to trundle it down the col. Chase and I rappelled in after, arriving to a crowded stance with now few options for good anchors.\n\nChase built a solid anchor in a good crack that we clipped to, but the stance was on a horrible ice slope. Otto and James stepped away to a better stance to give everyone more room, putting in a small two-piece anchor of a 0.4 and 0.3 cam on a sliding-x. A few moments later we all transitioned to the new anchor with the better stance and I added a #1 cam in a sliding-x for a third piece of gear.\n\nOnce settled, we decided Otto could lead the next pitch while I jugged up and sorted the stuck rappel ropes. At this point Chase also had to fix the 7mm tagline to the anchor to rappel and retrieve a rope that had fallen off his backpack below us. Soon enough, Otto had climbed the next pitch and built a new anchor, I had come back down to the anchor and was clipped in, and Chase was still on rappel below us. James was standing next to me at the anchor, having just belayed Otto.\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/07.jpg]\n\nPING PING PING. Three distinct noises back to back. The anchor cams ripped from the wall.\n\nI remember being torn from the wall and starting a chaotic tumble staring at a 1000ft drop below me to the glacier. In that moment I distinctly remember thinking “ I am dying right now, tethered to two of my friends. We are tumbling to our death.” I remember helplessly trying to grab any surface I could while the weight of all three of us pulled us downward. And then suddenly…we stopped.\n\nNone of us had any clue what had happened. Why are we alive? “Did the rope catch on something? What failed? Will we die if we move”?\n\nAfter a couple of breaths I look around me. James is suspended above me, his tie-in to Otto’s climbing rope pulling his harness upward and the anchor sling with the weight of me and Chase pulling his harness downward. I am hanging off of my personal tether to the anchor sling hanging from Jame’s harness. Chase’s rappel rope was still clipped to the anchor sling, with Chase was 30ft below us on rappel. He had backfliped while falling and dodged a microwave-sized rock that dislodged from part of our anchor.\n\nStill not knowing exactly what we were hangin on, I quickly did what I could to secure us, clipping to the rappel ropes still hanging above us and building a makeshift cam anchor next to me. Once secure, we took a breath to assess what the fuck just happened.\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/08.jpg]\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/09.jpg]\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/10.jpg]\n\nThe anchor failed because the crack was two pieces of a fractured rock held together by the now-melting ice. One side shifted and broke off causing the cams to fail, sending James, Chase and I tumbling 30ft. James was caught from his climbing rope above because Otto had already put him on belay. Chase and I hung off of the anchor sling clipped to James.\n\nWe yelled up to Otto, telling him to add more gear to the anchor. As he added gear as we began un-sorting our mess of ropes, making a plan to microtrax the taught rope one-by-one up to him. At the belay we gathered ourselves and agreed we were going to bail. We started down the Argentina route on the west side of Mermoz, taking extra caution on the descent and building backup anchors during each rappel (which you should do anyways in the alpine). Chase and I cried together as the reality of our experience set in. Eventually we made it back to camp and town the next day, sobered with our memories.\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/11.jpg]\n\nIn hindsight, and during many conversations after, we all agreed that we each played minor parts in complicitly allowing this accident to happen. When we switched from the good anchor to the one with the better stance, no one questioned the rock quality or checked the anchor. No one planned on having all three of us leaning on that anchor at the same time, and we all failed to communicate those details to each other. The anchor was a series of two sliding x’s, it would have been just as easy to create a non-extending anchor but the good stance and “time-cutting” mentality had us overlook this. And most importantly, we realized that the new anchor was in a giant block surrounded by melting ice. We knew the temperatures were warm, we knew anchors were melting out and we still didn’t critically think about if that anchor was the best possible rock to build it in. It had the better stance, so that’s why we went there. These were ultimately the wrong decisions that led to the accident.\n\nThere were also a handful of good habits that most likely saved our lives. At one point I changed my attachment to the anchor from a non-locking carabiner to a locking carabiner. The non-locker almost certainly would have twisted and unclipped in the slack mess of anchor sling as we were falling. Chase was using a prusik and knots in the end of his rope when he was rappelling. He most likely would have lost control of the rope and rappelled off of the end while falling if he didn’t have those in place. It is my opinion that safety is a habit and I write this as a reminder that those habits might be the thing that saves your life when you least expect it. Too many years of cumulative life could have ended due to the difference between a locker and non-locker.\n\nMy goal in recounting this experience and this trip is to normalize telling a holistic experience of what can happen in the mountains. I don’t see much use in recounting heroic tales of success without also the lessons of failures and mistakes. How is the next generation of climbers supposed to learn from the mistakes of others if no one shares their stories? Wouldn’t failures be the best opportunities to learn from?\n\nI would also like to see a changing narrative in climbing storytelling that highlights good decisions rather than good outcomes . As a group, we need to be better about owning up to our decisions and mistakes and sharing honestly our experiences. I want to hear more stories of bailing and failed outings (or successes!) centered around decision making and good judgement. Those are the experiences that we have the potential to gain wisdom from, and therefore what should be shared. What good is it to hold back a lesson that could save someone's life for the sake of ego?\n\n[photo: images/journal/patagonia-pt-2-a-near-tragedy/12.jpg]"
      },
      {
        "id": "mt-bute-beta-logistics-report",
        "title": "Mt. Bute Beta/Logistics Report",
        "date": "",
        "dateLabel": "",
        "meta": "Beta and logistics",
        "lede": "",
        "cover": "images/journal/mt-bute-beta-logistics-report/01.jpg",
        "credits": [
          "Written by Keenan Nowak"
        ],
        "pullquote": "",
        "body": "We thought that Bute was an amazing zone with tons of potential. Half of the adventure (if not more) was the process of figuring out how to get in there– so be warned, reading this beta report will rob you of some of that experience. We chatted at length about the ethics of posting such a detailed beta report and came to the conclusion that this is just part of modern alpine climbing– the choice is yours, whether you decide to use .gpx tracks and follow detailed beta or go for the full-experience bushwhack adventure. That said, the routes could use a bit more traffic to clean them up and we hope that this information will help facilitate a few more trips out there in the coming years.\n\nHuge thanks to Jimmy Martinello, Luke Neufeld, and Blake Herrington, each of whom shared beta with us before we headed up for our trip. Cheers to Jimmy and his partners Bruce Kay and Jay Sinnes for the vision in putting up the route– what an adventure!\n\nApologies in advance for my wordiness in this report… got carried away with stoke while thinking back on the trip. If you aren’t partial to long reads, see the bottom of the document for a TL;DR. Bon voyage!!\n\n## Travel Logistics\n\nWe booked our approach from Heriot Bay (Quadra Island) to Homathko Camp (Bute Inlet) with Wild Waterways Adventures, which is owned and operated by Jenefer Smalley and Rueben Buerge. They were the second cheapest option we found, but the best deal when considering their scheduling flexibility and the size of their boat– which they promised would be able to handle Bute Inlet’s infamous outflow winds. Weather in the inlet can be a real doozy– make sure your charter has an appropriately sized boat and experience in the area. Reuben and Jen were super generous in their ability to accommodate our weather-dependent plans and adjust the drop-off/pick-up schedule as needed, all of which was coordinated via InReach. Jen even brought us a big jug of lemonade for the return trip… pretty awesome after several days of dehydration!\n\nOn our way out, one of the engineers working out of Homathko Camp suggested that we should have come via fixed wing with Vancouver Island Air. This could be a good option– worth a call!\n\n## Approach to Basecamp\n\nWhile planning the trip we talked to four people who had previously been out to climb various routes on Mt Bute. Most had chosen the fly in option, taking a helicopter at least one way up to the alpine near Bute. Those who had bushwhacked up the Galleon Creek endorsed it to be character building at best. We can verify the difficulties, but also have a .gpx file that will save you many hours of wallowing up loose dirt slopes covered in blow-down and devils club. Thank us later… latte donations accepted. Our initial attempt to rely on satellite imagery, word of mouth beta, and instinct doubled the approach time on the way in and added at least one sketchy river crossing. Young and dumb, what can we say!\n\n[photo: images/journal/mt-bute-beta-logistics-report/02.jpg]\n\nThe correct route starts from Homathko Camp on a well-established logging road. When we journeyed in, it was active with equipment and bridges in place. On the way out, the equipment and several small bridges had been pulled out. This may change in the future, so be prepared to encounter active logging\n\nOnce you hit Galleon Creek, follow the road upstream for another ~1.5km until you reach a massive log jam just after the 5km road marker sign. There was previously a bridge at this location, but the log jam serves the same purpose for both wildlife and climbers alike. I’d be surprised if this log jam blows out anytime soon, as it appeared to be reinforced with cable. But who knows– no guarantees! Once across the jam, continue on the very-overgrown road for approximately 4km until it peters out– in the below picture, this is approximately where the pink track becomes purple. This location was our first campsite during the heinous approach to basecamp. However, I don’t think there would be any issue for a fit party to reach basecamp in a push if you use our descent track (above). Refill your water here!\n\n[photo: images/journal/mt-bute-beta-logistics-report/03.jpg]\n\nAfter this campsite and the transition to bushwhacking, you will follow vague game trails peppered with occasional flagging tape and other signs of human presence– including some bucked up logs/trail building efforts. You will find this trail by ascending about 50-100m above the campsite. To our knowledge, none of the previous climbing parties brought a saw up there– anyone’s guess who did the trailwork, our thanks to them! Stay on this path for as long as you can, and if you lose it, stay close-ish to Galleon Creek throughout the rest of the hike and follow the path of least resistance. You will encounter several slide drainages and cross at least one trickling creek. Stick to coniferous patches of forest as much as you can for easier travel. Eventually, you will get to a “meadow” (bog) with views of Bute itself. Crossing the meadow means wet feet, but you are almost to camp and it saves a good amount of struggle compared to going around. Just ask Hayden and Christian – they tried to go around on the descent, but their weeny little approach shoes got wet despite their best efforts. I wore massive Scarpa fire boots that kept my feet dry, but ask me how much they felt hanging off my harness while simul-climbing behind the monkeys– I need a couple more years to recover from that struggle. Once across the meadow, you will encounter very thick brambles. Since your stoke will probably be high at this point (almost done the hike!), just crash right through them. When you eventually trip on a vine, the other brambles offer a soft catch– not too shabby. You will eventually pop out at the old growth thicket that serves as base camp.\n\n## What not to do on the approach\n\nWe followed some bad beta and tried to hug the cliff walls that guard the north side of the drainage. This led us to an extended section of heinous sidehilling that wove through extremely dense horizontally-growing maple trees (see below track in purple). Not recommended! There is definitely climbing potential along this band of cliffs, but it pales in comparison to Mt. Bute and the walls near its base.\n\n[photo: images/journal/mt-bute-beta-logistics-report/04.jpg]\n\n## Base Camp\n\nOnce you pop out of the thick bushes, head for the lowest ground within the slightly sloping old growth grove. We happened to pop out of the bushes at the southwest corner of the grove, which has an obvious fire ring and signs of prior camps. This is a sweet hang-out spot where we spent all of our down-time. If you follow flagging tape along the south (low) side of the grove, you will find a relatively flat spot with room for three tents. We had two heavy rain days and were well sheltered by the trees in both the hang-out area and the sleeping area. Water is plentiful and clean, as both of these sites have easy access to the main vein of Galleon Creek, as well as its tributaries.\n\n[photo: images/journal/mt-bute-beta-logistics-report/05.jpg]\n\n## Accessing School of Rock\n\nBy our count, the approach from basecamp to School of Rock has been established at least three times. However, it is an absolute coastal jungle and regrows faster than my facial hair– that’s not saying much, but nonetheless you’ll probably have to cut the trail anew. Definitely do it on a rest day– it would suck to crash through the bush all morning and then try to get anywhere on the route on the same day. To find the approach path, head to the southeastern edge of the old growth grove (not far from the tentsite) and find a small log crossing a stream, which then leads you back to coniferous forest. Follow flagger, cut logs, blazed trees, and our .gpx while you navigate through the coniferous forest alongside the main vein of Galleon Creek. The crux of this approach is finding a safe spot to cross this main vein– we got lucky and found a tree down across it, which we supplemented with another small tree. Definite no-fall zone over the raging creek when we went– hopefully less sketchy for you! If this crossing is not an option, we did hear that one party went upstream until the tributaries became small enough to wade across. We tried to do that on our first scouting day and didn’t see any great spots before we decided to try the lower crossing, but we may not have gone far enough upstream.\n\n[photo: images/journal/mt-bute-beta-logistics-report/06.jpg]\n\nOnce across Galleon Creek, you really get amongst the bushes. If you were able to cross the creek where our .gpx did, you can keep following our track– otherwise, just try to generally head in the direction of the route base. There are intermittent patches of coniferous forest that provide much easier travel than the bush. Stick to these and head for the talus slope. If you’re on our .gpx track, you will skirt around large boulders before the grade of the slope kicks up and you start to hit the talus field. The start of the route is the obvious end of this talus field– a massive slab that heads up to your left. It was a bit of a waterfall when we were there!\n\n## Climbing Strategy & Route\n\nWe chose to leave basecamp at 0300 rather than carry a sleeping kit up to the base of the route and bivy there. In hindsight, I might have preferred to have a few extra hours of sleep and do the hike the prior day. We were on the route by 0600. The section of the route that we climbed can be broken down into 3 sections: the slab, the bushes, and post-bushes. It would be impossible to share the exact route we took once we hit the bushes, nor would we recommend following it… but this should give you an idea of where we went. In speaking with a member of the FA party post-trip, it became abundantly clear that we followed a very different route from them during our “bushes” section– so keep an eye out for potential ways to find clean rock. We didn’t have much luck in that department, but we must have missed a better line!\n\n[photo: images/journal/mt-bute-beta-logistics-report/07.jpg]\n\nThe first ~1000ft of the route is a ~40m wide low angle slab with a dyke feature in the right hand corner. Difficulties stay around 5.7 the whole way up, but protection is sparse. We chose to simul-climb the majority of the route, this slab included– but at least one party has soloed the slab. Initially, Christian led up the centre of the slab, but eventually found better gear in the dyke corner. There was running water cascading down this corner, but for the most part we were able to stem and avoid it. There were two small sections that we were forced to solo given a lack of gear, and multiple 80ft runouts. Not for the faint of heart– Christian really entered a zen-like state from here on up.\n\nAfter this slab, we traversed into the bushy/vertical terrain on the buttress. This is where we may have deviated from the FA line, so consider other options if you see them. Rope drag was an issue, so the followers tied in about 10m/20m from the end of the rope and trailed the rest. The last follower also trailed the tagline. For what felt like forever, we quested through 5.9++ bush pulls, slinging greenery and plugging the occasional crack for protection. Run out. I found this to be burly even as the follower– the experience of yarding yourself up cedar shrubs with poor feet for 1000ft is something akin to doing a bajillion weighted AND band-assisted pull-ups. That analogy makes sense, right? Anyways, it was gruelling. Christian put in some real work through this section, and Hayden took over once we reached the less-bushy but still organic-filled upper section.\n\nHere, we attempted to cut out to the ridge (skyline of above photo). Again, this felt like it took forever, with many false-ridge summits. We encountered a small amount of thin 5.10 climbing in this section, but it protected well with nuts. Hayden found one abandoned #6 cam, which leads us to believe we were on a somewhat similar route to previous parties at this point. Would love to know who bailed off of the 6– it’s still there, as we opted to climb a neighbouring crack. We were very dehydrated and out of water by this point, having only encountered one small puddle thus far. Needless to say, we drank every muddy drop from that puddle. Eventually, we gained the ridge and found a chunk of snow with a healthy drip. It looked like another party had made camp here– we found a tattered Patagonia fleece sweater. We refilled our bottles, made our way several hundred feet higher to a larger chunk of snow (no drips…), and made our bivy on a flat rock. We had been on the route for approximately 13.5 hours at this point. After running out of fuel the next morning, we headed for the first sub-summit of Mt Bute via more discontinuous alpine climbing. The route looked waterless until the next sub-summit, which was at least another 1500’ of technical climbing away. We made the decision to bail from there. In retrospect we may have been able to fill our bottles at the snowfield below the first sub-summit and hike back to the route, but it would have been touch and go to get to the top before the forecasted rain arrived\n\n## Descent\n\nSee .gpx. There is a convenient descent route that follows grassy knolls down the south side of the peak. We did one rappel to access the walking, then traversed into the forest (steep!) where we had to do one or two more raps. Eventually we reached a good spot to rap over the cliff (three 65m raps?) and return to the start of the climb. We found tat midway down, so it looks like we hit the same spot as previous parties. These rappels will bring you to a large forested ledge that you can traverse back to the base of the slab.\n\n## Gear\n\nWe took a double rack from 0.2-3, a 4, offset nuts, a 65m tagline, and a 70m rope. Many microtraxions– at least 3. Selection of knifeblades, which we didn’t use. Ice axes and crampons (ice axes came in handy on the steep bushy descent). We started the slab with ~2-2.5L of water each.\n\n[photo: images/journal/mt-bute-beta-logistics-report/08.jpg]\n\n## Weather and Season\n\nOur trip fell early August, and if you read our trip report you’ll know that we got totally skunked for water on the route. From my memory, there was a relatively large snowpack the previous winter and a late start to alpine climbing season. Be prepared for rain, no matter what time you go! Our weather window was short and ended up being one of the factors that led us to bail. We had a dedicated “weatherman” (big thanks to Vitaliy Musiyenko) who supplied us with SpotWx-generated forecast models via InReach.\n\n## Takeaways/TL;DR\n\nEmail us for the .gpx file. It will save you many hours and much struggle.\n\nBring a machete or two and a folding hand saw to navigate the bushwhack between basecamp and the base of the route.\n\nCarefully plan your trip timing– we went at the beginning of August and got skunked for water on the route despite a very late start to the summer/large snowpack.\n\nMake sure to have a friend who can interpret the various readily-available weather models and send you updated forecasts."
      }
    ],
    "header": {
      "images": [
        {
          "src": "images/words-second.jpg",
          "focus": "center 42%",
          "credit": "Photo · Vitaliy Musiyenko"
        },
        {
          "src": "images/words-opener.jpg",
          "focus": "center 50%"
        }
      ]
    }
  },
  "media": {
    "kicker": "Media",
    "title": "Media",
    "lede": "Published writing, films, interviews and podcast appearances.",
    "film": {
      "title": "All Grown Up",
      "meta": "Dirtbag Fund",
      "blurb": "",
      "url": "https://www.youtube.com/watch?v=6xC_V8TsYxM",
      "poster": ""
    },
    "links": [
      {
        "id": "aaj",
        "kind": "Writing",
        "publication": "American Alpine Journal",
        "title": "Brilliant Blue",
        "year": "2024",
        "url": "https://publications.americanalpineclub.org/articles/13201216837",
        "note": "First ascent of White Sapphire, Kishtwar Valley"
      },
      {
        "id": "xc265",
        "kind": "Writing",
        "publication": "Cross Country Magazine",
        "title": "Fight or Flight",
        "year": "Issue 265",
        "url": "https://xcmag.com/magazine-articles/adventure-and-inspiration/fight-or-flight/",
        "note": "Para-alpinism in the Cordillera Blanca"
      },
      {
        "id": "gearjunkie",
        "kind": "Writing",
        "publication": "GearJunkie",
        "title": "Gear reviews and testing",
        "year": "",
        "url": "https://gearjunkie.com/author/cblack",
        "note": ""
      },
      {
        "id": "climbing",
        "kind": "Writing",
        "publication": "Climbing",
        "title": "Instructional articles",
        "year": "",
        "url": "https://www.climbing.com/byline/christian-black/",
        "note": ""
      },
      {
        "id": "cutting-edge",
        "kind": "Podcast",
        "publication": "The Cutting Edge",
        "title": "Brilliant Blue on White Sapphire",
        "year": "",
        "url": "https://open.spotify.com/episode/41l2FZsr6P5TJMw7TJtEG1",
        "note": "American Alpine Club",
        "embed": {
          "service": "spotify",
          "id": "41l2FZsr6P5TJMw7TJtEG1",
          "start": "1396"
        }
      },
      {
        "id": "xc-podcast",
        "kind": "Podcast",
        "publication": "Cross Country Magazine",
        "title": "The Paragliding Podcast, episode 5",
        "year": "",
        "url": "https://xcmag.com/podcasts/the-paragliding-podcast-episode-5/",
        "note": "",
        "embed": {
          "service": "spotify",
          "id": "5tQdoYNdpDb1NWHo5hlwLX",
          "start": "0"
        },
        "extra": [
          {
            "label": "Watch the excerpt",
            "url": "https://www.youtube.com/shorts/UHOrrVIFSto"
          }
        ]
      },
      {
        "id": "all-grown-up",
        "kind": "Film",
        "publication": "Dirtbag Fund",
        "title": "All Grown Up",
        "year": "",
        "url": "https://www.youtube.com/watch?v=6xC_V8TsYxM",
        "note": ""
      },
      {
        "id": "instagram",
        "kind": "Social",
        "publication": "Instagram",
        "title": "@crustacean_black",
        "year": "",
        "url": "https://www.instagram.com/crustacean_black/",
        "note": ""
      },
      {
        "id": "youtube",
        "kind": "Social",
        "publication": "YouTube",
        "title": "@christianblack1",
        "year": "",
        "url": "https://www.youtube.com/@christianblack1",
        "note": ""
      }
    ]
  },
  "about": {
    "kicker": "About",
    "seoTitle": "About Christian Black — Climber, alpinist, paraglider pilot",
    "title": "Christian Black",
    "positioning": "Rock and alpine climber, writer, photographer and storyteller",
    "lede": "“Have fun, be safe, look cool!”",
    "portrait": "images/about-at-work.jpg",
    "portraitAlt": "Christian Black hanging on a rope on El Capitan with a camera, Yosemite behind him",
    "portraitEnd": "images/portrait-cb.jpg",
    "portraitEndAlt": "Christian Black on a summit at night, arms raised in a crab pose",
    "contact": {
      "title": "Get in touch",
      "blurb": "For inquiries, media requests, licensing or collaboration.",
      "image": "images/about-summit.jpg",
      "credit": ""
    },
    "header": {
      "image": "images/about-backdrop.jpg",
      "focus": "center 45%",
      "credit": "Photo · Dan Teitelbaum"
    },
    "intro": "Christian Black is a multidisciplinary climber and storyteller based in the Las Vegas area.\n\nOriginally from Texas, Christian started climbing in college at the age of 19 and eagerly pursued a direction far from his upbringing. After formative years working for the National Park Service in Yosemite and Sequoia and Kings Canyon National Parks, Christian took his pursuits abroad to Patagonia, the Indian Himalaya, China, Peru, and Alaska. His interests vary from sport and boulder projecting to high-altitude technical alpinism and paragliding adventures. \n\nIn addition to athletic pursuits, Christian enjoys many types of storytelling through writing, photography or video. His work can be found published in outlets such as the American Alpine Journal, Climbing Magazine, Dirtbag Fund Films, Cross Country Magazine, and more. \n\nWhether climbing, flying, or shooting, Christian can always be found exploring the world through more than one medium. Among friends he is known for his crab poses and climbing catch phrase “have fun, be safe, look cool!”",
    "break": {
      "image": "images/about-sport.jpg",
      "credit": "Photo · Dan Teitelbaum"
    },
    "outreach": {
      "heading": "Outreach",
      "image": "images/about-outreach.jpg",
      "credit": "",
      "side": "left",
      "text": "To give back to the community that gave him so much, Christian spent formative years volunteering as a Yosemite search and rescue (YOSAR) member, Yosemite climbing ranger, and Denali rescue volunteer. These years gave him a deep respect for risk that continually shapes his interactions with the mountains, a topic he writes openly about in his essays in hopes of moving forward a culture of healthy risk. He has enjoyed sharing his depth of skills, hosting free self-rescue clinics at film screenings, climbing gyms, and developing the Climber Coffee self-rescue clinics for the Yosemite climbing ranger program during his time as a ranger. "
    }
  }
};
